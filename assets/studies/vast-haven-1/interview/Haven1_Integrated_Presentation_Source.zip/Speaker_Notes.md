## Slide 1

Opening: I built a representative Haven-1 thermal-control study to demonstrate how I approach requirements, active/passive control, detailed thermal and fluid analyses, hardware interfaces and test readiness. The mission context is habitation and research in low Earth orbit. Public dimensions and vehicle references guide the visual reconstruction. Internal hardware and numerical design values are explicitly assumed.
The engineering objective is to maintain avionics bulk 0–55 °C, battery 10–35 °C, payload 10–40 °C and cabin 18–27 °C across the assumed 24h mission. A separate 85 °C spreader-hotspot development limit is an analyst assumption, not a component junction rating. Mission clock starts at assumed sunrise, with 60minsun/30mineclipse. We compare one baseline and an improved configuration and investigate a reduced-flow fault.
The toolchain is OpenModelica for integrated mission dynamics and hydraulic pressure balance, OpenFOAM for liquid-channel CFD, and FreeCAD/CalculiX for geometry, solid conduction and thermoelasticity. These tools demonstrate transferable methods. They do not establish Thermal Desktop-specific proficiency. This project includes a TVAC pretest model and procedure outline, not executed chamber testing.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: https://www.vastspace.com/haven-1
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 2

The embedded silent assembly movie shows the existing 221 named station solids, not a new manufacturing design. The 12subsystem groups help identify heat sources, resources and heat-rejection paths. The geometry is anchored to public exterior references. The 10.1mlength and 4.4mdiameter are context, not a certified pressure-vessel model.
This round adds a native FreeCAD subsystem file with 14 named geometric objects: a 300×200 mm cold plate with 12 parallel 300×8×2 mm water channels, a 0.5 mminterface layer,6 mmspreader, PCB and four device envelopes, transparent enclosure, headers, pump envelope and mounts. The packaging PCB/device solids are context. The solved 3Dthermal object is the spreader with a central 150×100 mm 600 Wheat patch. No chip junction or detailed multilayer PCB temperature is claimed.
The heat path is electronics through the spreader/interface into channel walls, then coolant and radiator. NativeFCStdandSTEPare delivered. CalculiX thermal and sliding-mount results are imported as native FreeCAD result objects, with viewer mesh converted from SI to mm and stress fromPa toMPa. Original SI inputs/FRD are retained.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../cad/Haven1_Avionics_Cooling.FCStd
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 3

The diagram maps heat paths in the actual native Modelica equations. Thirteen thermal nodes retain the station context: avionics, battery, payload, power conversion, ECLSS, cabin, wall, cold plate, coolant, radiator, CMG, solar array and tank resources. Electrical storage, pump and heater heat are included once in the energy ledger. Native thermal-capacitance components are named for navigation; the diagram here is a readable heat-path view, not a claim that decorative lines implement equations.
The new 600 Wavionics branch uses the same power throughout CFD,FEMandthemission model. OpenFOAM provides wall-to-inlet thermal resistance versus 0.5–2 L/min and channel pressure loss. The 3DsolidFEM provides the volume-weighted mean conduction contribution. Those form the avionics-to-coolant bulk resistance. The old direct avionics-to-coldplate link is removed to prevent double counting. Other station links remain inherited assumptions.
Flow solves an algebraic quadratic pump-curve/loop-pressure equilibrium including CFDchannel loss. The assumed pump curve has 70kPa shutoff head at reference speed, and the remainder-loop loss is 35kPa at 8 L/min. Pump efficiency 35%plus 5 Woverhead are assumptions. There is no selected flight pump, pump inertia, cavitation or detailed manifold model.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../system/source/Haven1Thermal.mo
../integration.json
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 4

The horizontal axis is elapsed mission time in hours from assumed sunrise. The vertical axis is bulk-node temperature in°C, not electronics junction temperature. All nodes begin 20 °C. Avionics is teal, battery ochre, payload blue and cabin red. The baseline uses a 10 m²radiator, approximately 8 L/mintotalloopflow,1 L/minavionicsbranch, fixed radiator connection and 0.020 K/WTIM resistance. The thermal environment is the inherited representative rectangular orbit, not a propagated Haven trajectory.
The table shows maxima over the first 24h; different components may peak at different times. Baseline peaks areAvionics 54.81 °C, Battery 33.87 °C, Payload 46.81 °C, Cabin 30.35 °C. Payload and cabin exceed their assumed limits. The steady local spreader at 20 °Cinlet peaks 91.28 °C; a mission-inlet-dependent full-power steady envelope is about 89.2 °C. This is a conservative local steady estimate, not an instantaneous transient hotspot measurement.
The study therefore identifies both a local interface problem and a system heat-rejection problem. We do not claim that fixing the interface alone resolves the whole station.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../system-summary.json
../data/baseline.csv
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 5

Left is the actual saved FreeCAD subsystem. Right are CalculiX steady 3Dsolidconduction fields, using one common 20–100 °Ccolor scale. XandYare millimetres across the 300×200×6 mmspreader. These are solid-spreader temperatures. The visible PCB is packaging context, not a resolved ECAD model. The central 150×100 mmtop patch rejects 600 W. The bottom uses a homogenized film equivalent to serial TIM plus CFD-derived wall-to-coolant resistance. This is an engineering reduction of 12 parallelchannels, not a fully resolved conjugate assembly.
For the controlled interface comparison, flow remains 1 L/min and TIM resistance drops 0.020 to 0.005 K/W. That corresponds to a 0.5 mminterface across 0.02 m²with assumed conductivities 1.25 and 5 W/mK. Peak falls 91.28 to 79.11 °C. Raising flow to 2 L/min then lowers it to 71.32 °C. Thus the two improvements are separated in the table, while the maps show baseline and final configurations.
The material is assumed isotropic Al-like k 167 W/mK.768hexelements refine to 2592; improved peak changes 0.0744 K and both rejectapproximately 600 W. Mesh agreement is numerical evidence, not proof of material/contact accuracy. The volume-weighted mean resistance feeds the mission model. Worst-case mission inlet and branch-flow conditions give a conservative steady hotspot envelope, separately reported from the transient bulk node.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../fem/summary.json
../source/fem.py
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 6

The upper image is an actual central-width plane of the OpenFOAM fluid temperature field for the 1 L/min total branch case. Xis 0–300 mm along one channel, Zis 0–2 mm across its height. The bottom wall receives 50 W perchannel;12identicalchannels represent 600 W. Other channel walls are adiabatic. The inlet is 20 °C. This is coolant flow, not vacuum exterior convection. Constant-property water usesdensity 1000 kg/m³,cp 4180J/kgK,k 0.6 W/mKandnu 1e-6 m²/s. Laminar screening andg=0are assumed.
The lower plots show mean channel-wall temperature and channel pressure loss versus total branch flow. At 0.5,1 and 2 L/min, mean wall temperatures are 50.71,43.56 and 38.31 °C, and pressure losses 44.78,91.10 and 188.13Pa. Doubling 1 to 2 L/minlowers the wall mean 5.25 °C. The bulk outlet rises 8.61 K at 1 L/minand 4.31 K at 2 L/min, consistent with 600 W/(mass flow timescp).
Both 1 and 2 L/mincases were refined from 5760 to 46080 cells. Wall means shift 0.280 and 0.212 K; channel pressure changesapproximately 4.48 and 5.00%. Both refined cases satisfy SIMPLE residual criteria. The fields solve prescribed wall heat flux, not coupled solid/fluid CHT. Manifold balancing, connections, filters and radiator losses are excluded from this local CFD and appear only as explicit system pressure-loss assumptions. Do not use these small channel losses as total pump head.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../cfd-summary.json
../verification/numerical-checks.json
https://www.openfoam.com/
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 7

Both maps use the same improved 600 Wthermalfield at 20 °Ccoolant inlet. Only the mechanical restraints change. CalculiX solves linear small-strain thermoelasticity withE69GPa,nu 0.33,alpha 23e-6/Kandstress-free 20 °C. Left clamps all translations atbothx-endfaces. Right permits expansion using akinematic/slidingidealization withminimalconstraints removing rigid-body motion.
Axes are panel millimetres. Colors show extrapolated nodal vonMisesstress on the top surface, inMPa, on one common scale. They are not raw integration-point stress or flight allowable margins. Clamped 95thpercentile is 58.34 MPa versus 26.53 MPa sliding. Movement rises 0.090 to 0.164 mm. The design implication is to accommodate thermal expansion while preserving assembly support.
The refined clamp maximum rises 72.55 to 83.05 MPa, revealing restraint sensitivity. We do not claim a qualified safety factor or minimum thickness. Pressure, launch acceleration, vibration, fastener preload, friction, fatigue and plasticity remain outside this thermal-expansion study. A drawing review should specify the slot/flexure direction, motion envelope, TIM compression and bolt preload, then verify with the structural team.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../fem/summary.json
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 8

The native editable bar chart compares first-day maximum bulk temperatures. Gold is baseline and teal improved. Component maxima areAvionics 54.81 to 35.92 °C; Battery 33.87 to 26.62 °C; Payload 46.81 to 39.23 °C; Cabin 30.35 to 22.94 °C. All four improved nominal histories stay within their assigned bulk bands for this initialized 24hcase. This does not establish every component, orbit or lifecycle requirement.
This final comparison combines three deliberate design changes: radiator 10 to 16 m², branch flow 1 to 2 L/min, andTIM0.020 to 0.005 K/W. The preceding local studies isolate interface and flow effects. Area change also raises radiator effective heat capacity 70 to 112kJ/K, addressing the earlier constant-capacitance simplification. Optical properties/view assumptions remain fixed. Actual radiator mass, mounting and deployment remain unselected. The 42kJ/Kincrease corresponds to 46.7 kgequivalentAlthermalmass atcp 900J/kgK; this is not a measuredBOMmass.
Total loop flow increasesapproximately 8 to 10 L/min through an assumed pump-speed command. Pump energy rises 0.440 to 0.746 kWh/day. The cold comparison is a separate matched sensitivity:50%equipment load and 80%environment/PV. Fixed coupling uses 17.679 kWh versus 0 for bypass in that case. The cold fixed case drives the coolant bulk to−8.97 °C, outside the valid liquid-water assumption. Its 17.68 kWhis a no-phase-change mathematical comparison, not a physically valid water-loop heater sizing result. The cold-bypass radiator node reaches−34.90 °Cwhilebulk coolant remainsabove 14 °C. Radiator metal temperature is not a resolved fluid temperature, but a water-filled isolated radiator could freeze. The external fluid and heat exchanger are not separately resolved. A freeze-safe external coolant circuit, fluid isolation/draining strategy or dedicated freeze protection must be designed and checked. Do not claim the current architecture is freeze-safe. Retain backup heaters: other startup/fault conditions consume heat. Larger radiator, higher flow and better interface carry mass, power, assembly and procurement costs requiring actual vendor data.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../system-summary.json
../integration.json
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 9

The left plot now focuses on payload temperature, the limiting component under reduced flow. The horizontal axis is elapsed mission hours and the dashed line is the 40 °Cstudy limit. The right plot shows total heater power inW. Curves are nominal,5 °Ccoldstartwith 20ssensorlag,50%flowlossat 12h, andflowlosswithprotection. In the pump-curve model, a 50%speed reduction produces approximately 50%flow, not a manually imposed temperature response.
The unprotected payload reaches 40.652 °C. A flow measurement below 75%of nominal enables protection; a 20sfirst-order payload sensor triggers a latched 15%payload-power reduction when sensed temperature exceeds 39.5 °C; this holds the peak to 39.515 °C. The reduced electrical load is consistently removed from the payload heat and electrical power ledger. A real implementation needs system-approved load priorities, independent limits and sensor failure handling.
Cold startup initializes all lumps 5 °Cand uses 20ssensorlag. It consumes 0.0916 kWhheaterenergy. Initial temperatures lie outside several operating bands; this is a warm-up scenario, not a claim the system meets operating requirements fromtimezero. This startup is unoccupied, with crew heat set to zero. The cabin stays below the occupied 18 °Cminimum, so crew entry would require a separate warm-up/ready gate. It is not an occupied-operation pass.
Numerical evidence:10sto 5smaximumstep shifts the worsttemperature 4.81e-5 K. Independent event-aware energy quadrature residual falls 0.01849 to 0.00463 kWh. Mesh refinement and heat/mass closure are separately recorded. A separate+10%equipment-load sensitivity reaches 42.04 °Cpayload and exceeds the 40 °Ctarget. Nominal success therefore has limited uncertainty margin. Additional radiator/interface capacity or a lower allowed payload power is required before claiming robust compliance. Freezing is another unresolved gate: radiator metal is below 0 °Cin nominal and cold cases, and cold-fixed coolant bulk fallsbelow 0 °C. Phase change is absent; external fluid freeze protection needs its own design and testing. Failure recovery remains an assumed control demonstration, not flight software qualification.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../data/flow_fault.csv
../data/flow_protected.csv
../verification/numerical-checks.json
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006

## Slide 10

TVACmeans thermal vacuum testing. Hardware operates inside a chamber with evacuated exterior and controlled radiative and conductive boundaries. Removing air suppresses exterior convection; pressure alone does not set the hardware temperature. Chamber shrouds, coolant feedthroughs and support fixtures establish the heat paths. Gravity remains. A pressurized article requires appropriate maintained internal pressure and an approved pressure design.
The graph is a computed PRETEST prediction, not test data. Xis test timehours, Yis bulk-box°C. The example applies 300 Wfor 0–2h,600 Wfor 2–5h,thenpoweroffto 8h. Cold boundary uses 223.15 Kshroudand 5 °Csink; warm boundary uses 323.15 Kshroudand 25 °Csink. The representative model uses 30kJ/Kbulkcapacitance,improvedFEMresistance,emissivity 0.8,0.25 m²radiationareaand 0.22 W/Ksupport/wireleak to 20 °C. These are proposed fixture assumptions; chamber fixtures and radiation differ from the flight model.
Thermal balance compares measured steady heat paths and temperatures with predictions. Thermal cycling checks functionality through tailored hot/cold exposures. Place calibrated sensors at heat-source center/corners,TIM interfaces,coldplate inlet/outlet,mounts,fixtureandshroud. Measure electrical power,coolantflow,pressureandfunctionaltelemetry. Predict readings beforetest.
The procedure proposes stabilizationbelow 0.1 K/h for 1h and developmentcorrelationtargetswithin 3 Kand 15%timeconstant, subject to uncertainty and program approval. Fit bounded contact/emissivity against selected data,freezeparameters and predict anothercase. No test levels/cyclecounts are asserted as Vast requirements. The matrix distinguishes numerical work from test readiness and actual testing. The delivered README and evidence map link each job duty to model,plot,requirement,design decision or unresolved test gate. Procurement cost/schedule estimates require actual drawings/quotes; no invented approval is claimed.

Scope and evidence: independent public-reference engineering demonstration. All unpublished geometry, materials, loads, limits, interfaces, pump curves and control settings are study assumptions. No Vast flight configuration, manufacturer validation or qualification is claimed. Numerical verification and physical validation are distinct. TVAC is planned; zero physical tests.

Sources: ../tvac/Test_Plan.md
../tvac/predictions.json
https://www.nasa.gov/reference/jsc-thermal-vacuum/
https://www.esa.int/Enabling_Support/Space_Engineering_Technology/Test_centre/Thermal_Data_Handling_Facilities
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#integrated
https://job-boards.greenhouse.io/vast/jobs/4690307006