# Current compact Haven-1 presentation source

The presentation now has seven slides. Native graphs and diagrams remain editable, and each slide includes detailed speaker notes. The assembly video is embedded on slide 2.

This archive contains the compact-edit source. Preserve the existing project layout in the original analysis/CAD downloads. Run from presentation/compact-edit-20261029 with the installed @oai/artifact-tool runtime and its Node module path. Place build_compact.mjs in .build/, notes.json in source/, and the other source helpers under source/.

The immutable original 18-slide input is available at:
https://raw.githubusercontent.com/mrkhani88/khani-solutions-site/54c6617ac3939de4313ce6762b40057bd5f190bb/assets/studies/vast-haven-1/interview/Haven1_Thermal_Engineering_Interview.pptx
Save that input under presentation/revisions/20261029-before-condense/Haven1_Thermal_Engineering_Interview.pptx.

The current seven-slide deck is the canonical website download. The initial-analysis source archive retains its original 18-slide authoring history; this compact archive supersedes its presentation source. Physics sources and results did not change.

Workflow: build_compact.mjs, embed_video.py, finalize.mjs. Update local runtime paths before reproduction. The finalizer requires RUNTIME_NODE_MODULES. Native PowerPoint playback was not tested in this edit.
