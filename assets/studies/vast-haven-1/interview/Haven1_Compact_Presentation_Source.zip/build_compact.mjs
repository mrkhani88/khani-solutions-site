import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
import {applyPresentationChartFont} from '/Users/reza/.codex/plugins/cache/openai-primary-runtime/presentations/26.1017.22136/skills/presentations/container_tools/artifact_tool_utils.mjs';
async function main(){
const root=process.cwd(),pres=path.dirname(root),stage=path.dirname(pres);
const P=await PresentationFile.importPptx(await FileBlob.load(path.join(pres,'revisions/20261029-before-condense/Haven1_Thermal_Engineering_Interview.pptx')));
const keep=[0,2,5,6,9,10,12];P.slides.keep(keep);
const C={navy:'#142B3D',teal:'#087F95',gold:'#AD7A22',blue:'#4675AD',muted:'#587081',light:'#E4EBEF',red:'#B34C4C',white:'#FFFFFF'},font='Arial',hub='https://khanisolutions.com/AISolutions/vast-haven-thermal.html';
const notes=JSON.parse(await fs.readFile(path.join(root,'source/notes.json'),'utf8'));
function txt(s,str,x,y,w,h,size=26,color=C.navy,bold=false,link){const sh=s.shapes.add({geometry:'textbox',name:str.slice(0,60),position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});sh.text=link?[[{run:str,link:{uri:link,isExternal:true}}]]:str;sh.text.style={fontFamily:font,fontSize:size,color,bold,wrap:'word',verticalAlignment:'top',insets:0};return sh;}
const titles=['Haven-1 thermal engineering','CAD and geometry','Integrated 1D thermal system','Subsystem temperature and heater trades','Thermal FEM and contact sensitivity','Thermal stress and mounting restraint','Internal-flow CFD'];
for(let i=0;i<P.slides.items.length;i++){
 const s=P.slides.items[i];
 for(const sh of s.shapes.items){const t=String(sh.text);if(/^\d{2} \/ 18$/.test(t))sh.text=String(i+1).padStart(2,'0')+' / 07';}
 const title=s.shapes.items.find(sh=>sh.position.top<100&&String(sh.text).length>8);if(title)title.text=titles[i];
 s.speakerNotes.text=notes[i].text;
}
const s1=P.slides.items[0];
for(const sh of s1.shapes.items){const t=String(sh.text);if(t==='Mohammadreza Khani, PhD')sh.text='Habitation and research in low Earth orbit';if(t==='Independent spacecraft analysis and interview demonstration')sh.text='Independent study by Mohammadreza Khani, PhD';}
const s2=P.slides.items[1];for(const sh of s2.shapes.items){if(String(sh.text).startsWith('Four named parts arrive'))sh.text='10.1 m × 4.4 m\nPublic-reference geometry\nFour parts per batch';}
const s3=P.slides.items[2];for(const sh of s3.shapes.items){if(String(sh.text).startsWith('Selected heat paths shown.'))sh.text='13 thermal nodes. 24 h simulation. 60 min sunlight / 30 min eclipse.';}
// Replace only the imported hot-results slide with two clearly separated native charts.
const snap=await P.inspect({kind:'textbox,shape,image,chart,table',limit:3000,maxChars:1000000});
const ids=[...new Set(snap.records.filter(r=>r.slideIndex===3&&/^(sh|im|ch|tb|ea)\//.test(r.id)).map(r=>r.id))];P.delete(ids);
const s=P.slides.items[3];s.background.fill=C.white;
txt(s,titles[3],56,38,1168,84,42,C.navy,true);
txt(s,'Hot case: radiator area',56,151,710,40,29,C.navy,true);
txt(s,'Cold case: radiator connection',831,151,395,74,29,C.navy,true);
const sum=JSON.parse(await fs.readFile(path.join(stage,'analysis/system-thermal/summary.json'),'utf8'));
const cs=Object.fromEntries(sum.cases.map(c=>[c.id,c]));
const cats=['Avionics','Battery','Payload','Cabin'];
const peaks=id=>cats.map(n=>Number(cs[id].nodes.find(z=>z.name===n).max_C.toPrecision(12)));
function bar(x,y,w,h,categories,series,ytitle,ymax){const c=s.charts.add('bar',{position:{left:x,top:y,width:w,height:h},categories,series,barOptions:{direction:'column',grouping:'clustered',gapWidth:75},hasLegend:series.length>1,legend:{position:'bottom',textStyle:{fontSize:18,fill:C.navy}},chartFill:C.white,plotAreaFill:C.white,xAxis:{textStyle:{fontSize:18,fill:C.navy},line:{fill:C.light,width:1},majorGridlines:null},yAxis:{title:ytitle,min:0,max:ymax,textStyle:{fontSize:18,fill:C.muted},majorGridlines:{fill:C.light,width:1}},dataLabels:{showValue:true,position:'outEnd',textStyle:{fontSize:18,fill:C.navy},numberFormatCode:'0.0'}});applyPresentationChartFont(c,{fontFamily:font});return c;}
bar(35,218,760,360,cats,[{name:'6 m² radiator',values:peaks('baseline'),fill:C.gold},{name:'10 m² radiator',values:peaks('larger_radiator'),fill:C.teal}],'Peak temperature [°C]',85);
bar(823,239,405,335,['Fixed link','Bypass'],[{name:'Heater energy',values:[cs.cold_fixed.heater_energy_kWh,cs.cold_bypass.heater_energy_kWh].map(v=>Number(v.toPrecision(12))),fill:C.teal,points:[{idx:0,fill:C.gold},{idx:1,fill:C.teal}]}],'Heater energy [kWh / 24 h]',10);
txt(s,'10 m² still misses battery, payload and cabin targets',56,596,735,61,24,C.red,true);
txt(s,'Matched low-duty cold cases',832,600,392,54,23,C.muted);
txt(s,'Khani Solutions',56,677,230,25,18,C.muted);txt(s,'04 / 07',1144,677,90,25,18,C.muted);txt(s,'Detailed evidence on the website',735,677,365,25,18,C.teal,false,hub+'#system');
s.speakerNotes.text=notes[3].text;
// Keep the imported evidence figures and table. Shorten only their summary wording.
const s5=P.slides.items[4];
for(const sh of s5.shapes.items){if(String(sh.text)==='46.59 / 40.06 °C')sh.text='46.59 / 40.06 °C';}
const s6=P.slides.items[5];for(const sh of s6.shapes.items){if(String(sh.text).startsWith('Clamp peak is mesh sensitive.'))sh.text='Same temperature field. Clamp peaks remain mesh sensitive.';}
const s7=P.slides.items[6];for(const sh of s7.shapes.items){if(String(sh.text).startsWith('Local wall benefit'))sh.text='Local temperature benefit remains below mesh uncertainty.';}
await fs.writeFile(path.join(root,'.build/slide-manifest.json'),JSON.stringify(titles.map((title,i)=>({slide:i+1,title,source_slide:keep[i]+1,notes_words:notes[i].text.split(/\s+/).length})),null,2));
for(let i=0;i<P.slides.items.length;i++){const b=await P.export({slide:P.slides.items[i],format:'png',scale:1});await fs.writeFile(path.join(root,'previews',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await b.arrayBuffer()));console.log('Rendered',i+1);}
await(await PresentationFile.exportPptx(P)).save(path.join(root,'.build/Haven1_Compact_Draft.pptx'));console.log('EXPORTED7');
}
main().catch(e=>{console.error(e.message);process.exit(1)});
