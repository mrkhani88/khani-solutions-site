#!/usr/bin/env python3
"""Animate the exact Stage-01 CAD tessellation on Intel with VTK/PyVista.

The movie presents an engineering assembly sequence, not a claimed manufacturing
procedure. 4 individual CAD solids arrive per batch, in installed coordinates.
The pressure enclosure/insulation visual envelopes remain transparent.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','8')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('LP_NUM_THREADS','8')
import json, math, time, csv, subprocess, argparse, hashlib
from pathlib import Path
import numpy as np
import pyvista as pv
from PIL import Image, ImageDraw, ImageFont

ap=argparse.ArgumentParser()
ap.add_argument('--source',type=Path,required=True)
ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--test',action='store_true')
args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
data=json.loads(args.source.read_text());parts=data['parts']
W,H,FPS=1600,900,24
INTRO,BATCH,OUTRO=2.5,1.3,5.0
COUNT=len(parts);NB=math.ceil(COUNT/4);DURATION=INTRO+NB*BATCH+OUTRO
BG=(7,15,29);INK=(239,246,255);MUTED=(157,178,201);ACCENT=(92,220,217)
fontdir=Path('/usr/share/fonts/truetype/dejavu')
def font(n,bold=False):return ImageFont.truetype(str(fontdir/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),n)
fonts={n:font(n) for n in (15,17,18,20,22,25,29,38,44)}
bold={n:font(n,True) for n in (17,20,22,29,38,44)}
def enclosure(p):return any(s in p['id'] for s in ('Cone_','Barrel_','Seam_','Insulation_')) or p['id']=='DomedWindow'
group_order=['structure','routes','thermal','power','avionics','eclss','attitude','propulsion','payload','habitation','radiator','solar']
order=sorted(range(COUNT),key=lambda j:(group_order.index(parts[j]['group']),j))
# The frame and transparent shell arrive first, then routed and functional systems.
batches=[order[i:i+4] for i in range(0,COUNT,4)]
group_names={'structure':'Structure & transparent enclosure','routes':'Coolant and ventilation routes','thermal':'Thermal control hardware','power':'Electrical power & storage','avionics':'Avionics & communications','eclss':'Life support & environmental control','attitude':'Attitude control','propulsion':'Propulsion hardware envelopes','payload':'Laboratory payloads','habitation':'Crew habitat','radiator':'Candidate heat rejection panels','solar':'Solar energy collection'}
pv.OFF_SCREEN=True
plot=pv.Plotter(off_screen=True,window_size=(W,H),lighting='three lights',border=False)
plot.set_background(tuple(x/255 for x in BG));plot.enable_anti_aliasing('fxaa')
plot.camera.position=(-8,-15,10.5);plot.camera.focal_point=(5.05,0,0);plot.camera.up=(0,0,1)
plot.camera.parallel_projection=True;plot.camera.parallel_scale=6.0
plot.camera.SetWindowCenter(0,.10)
plot.camera.clipping_range=(.1,100.)
actors=[];centers=[];meshes=[]
for p in parts:
    v=np.array(p['vertices'],dtype=float).reshape(-1,3)
    tri=np.array(p['triangles'],dtype=np.int64).reshape(-1,3)
    faces=np.column_stack((np.full(len(tri),3),tri)).ravel()
    mesh=pv.PolyData(v,faces);meshes.append(mesh);centers.append((v.min(0)+v.max(0))/2)
    a=plot.add_mesh(mesh,color=p['color'],opacity=.075 if enclosure(p) else 1.0,
        smooth_shading=False,specular=.35,ambient=.22,diffuse=.8,
        show_edges=False,reset_camera=False)
    a.SetVisibility(False);actors.append(a)
plot.render()
view_right=np.cross(np.array(plot.camera.direction),np.array(plot.camera.up));view_right/=np.linalg.norm(view_right)
view_up=np.cross(view_right,np.array(plot.camera.direction));view_up/=np.linalg.norm(view_up)
arrival_offsets=[-view_right*7+view_up*3,view_right*6+view_up*3,-view_right*5-view_up*3,view_right*6-view_up*2]

def project(world):
    r=plot.renderer;r.SetWorldPoint(*world,1);r.WorldToDisplay();x,y,z=r.GetDisplayPoint();return x,H-y
def wrap(text,maxwidth,f):
    words=text.replace(' / ',' / ').split();lines=[];s=''
    for word in words:
        test=(s+' '+word).strip()
        if f.getlength(test)>maxwidth and s:lines.append(s);s=word
        else:s=test
    if s:lines.append(s)
    return lines[:3]
def shortlabel(p):
    s=p['label'].replace('Candidate ','').replace('Representative ','').replace('envelope','').replace('assembly ','').replace('PV tile (visual subdivision)','PV tile')
    s=' '.join(s.split())
    return s[0].upper()+s[1:]
def draw_overlay(raw,t,bi,phase,active,showlabels):
    im=Image.fromarray(raw).convert('RGBA');layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
    # Top and bottom bands keep names and narrative out of the CAD volume.
    d.rectangle((0,0,W,117),fill=(*BG,247));d.rectangle((0,814,W,H),fill=(*BG,246))
    d.text((48,24),'HAVEN-1',font=bold[38],fill=INK)
    d.text((282,37),'CAD ASSEMBLY',font=fonts[20],fill=ACCENT)
    brand='khanisolutions.com';d.text((W-48-fonts[20].getlength(brand),35),brand,font=fonts[20],fill=INK)
    d.text((49,78),'Public-reference geometry  •  Proposed internal packaging  •  Colors identify systems',font=fonts[17],fill=MUTED)
    if t<INTRO:
        d.text((48,145),'221 named parts. Four arriving at a time.',font=bold[29],fill=INK)
        d.text((48,194),'The enclosure stays transparent so the interior remains visible.',font=fonts[22],fill=MUTED)
        d.text((48,236),'Parts settle at their CAD installation coordinates.',font=fonts[20],fill=MUTED)
    elif bi>=NB:
        d.text((48,150),'ASSEMBLY COMPLETE',font=bold[29],fill=ACCENT)
        d.text((48,197),'221 CAD parts positioned',font=fonts[22],fill=INK)
        d.text((48,235),'Next: system thermal, local thermal / structural and cabin-flow studies',font=fonts[18],fill=MUTED)
    elif showlabels:
        label_alpha=255 if phase<.9 else max(0,int(255*(1-phase)/.10))
        for k,j in enumerate(active):
            p=parts[j];x=43+k*390;y=138;cw=357
            col=tuple(int(c*255) for c in p['color']);fill=(*col,label_alpha)
            d.rounded_rectangle((x,y,x+cw,y+119),radius=11,fill=(17,33,51,int(label_alpha*.94)),outline=(*col,int(label_alpha*.7)),width=2)
            d.text((x+14,y+10),f'{bi*4+k+1:03d}  /  {COUNT}',font=bold[17],fill=(*col,label_alpha))
            for q,line in enumerate(wrap(shortlabel(p),cw-28,bold[20])):d.text((x+14,y+37+q*25),line,font=bold[20],fill=(*INK,label_alpha))
            d.text((x+14,y+94),p['id'],font=fonts[15],fill=(*MUTED,label_alpha))
            pos=np.array(centers[j])+np.array(actors[j].GetPosition());px,py=project(pos)
            if -10<px<W+10 and 255<py<808:
                d.line([(x+cw/2,y+121),(x+cw/2,y+143),(px,py)],fill=(*col,int(label_alpha*.8)),width=2)
                d.ellipse((px-5,py-5,px+5,py+5),fill=fill)
    if bi<NB and t>=INTRO:
        gs=list(dict.fromkeys(parts[j]['group'] for j in active));gtext=' + '.join(group_names[g] for g in gs)
        d.text((48,831),gtext,font=bold[20],fill=INK)
        n=min(COUNT,bi*4+(len(active) if phase>.68 else 0));counter=f'Batch {bi+1:02d} / {NB:02d}   ·   {n:03d} / {COUNT} installed'
    elif bi>=NB:
        d.text((48,831),'Engineering study model  •  Internal locations and hardware details include assumptions',font=fonts[18],fill=MUTED);counter='221 / 221 installed'
    else:
        d.text((48,831),'Transparent enclosure. Full component-by-component build.',font=fonts[20],fill=MUTED);counter='Preparing assembly'
    d.text((W-48-fonts[18].getlength(counter),833),counter,font=fonts[18],fill=MUTED)
    prog=min(1,max(0,(t-INTRO)/(NB*BATCH)));d.rounded_rectangle((48,876,W-48,882),radius=3,fill=(40,56,75));d.rounded_rectangle((48,876,48+max(1,(W-96)*prog),882),radius=3,fill=ACCENT)
    return Image.alpha_composite(im,layer).convert('RGB')

schedule=[]
for bi,ids in enumerate(batches):
    for k,j in enumerate(ids):schedule.append({'batch':bi+1,'start_s':round(INTRO+bi*BATCH,3),'settled_s':round(INTRO+bi*BATCH+BATCH*.69,3),'label_end_s':round(INTRO+(bi+1)*BATCH,3),'part_number':bi*4+k+1,'id':parts[j]['id'],'name':parts[j]['label'],'group':parts[j]['group'],'transparent':enclosure(parts[j]),'installed_center_m':list(map(float,centers[j]))})
(args.output/'assembly-timeline.json').write_text(json.dumps({'count':COUNT,'batch_size':4,'batches':NB,'duration_s':DURATION,'fps':FPS,'parts':schedule},indent=2))

def frame(t):
    bi=int((t-INTRO)//BATCH) if t>=INTRO else -1;phase=((t-INTRO)/BATCH-bi) if bi>=0 else 0
    if bi<0:active=[]
    elif bi>=NB:active=[]
    else:active=batches[bi]
    done=max(0,min(NB,bi))
    for b,ids in enumerate(batches):
        for k,j in enumerate(ids):
            a=actors[j]
            if b<done or bi>=NB:a.SetVisibility(True);a.SetPosition(0,0,0)
            elif b==bi:
                a.SetVisibility(True)
                u=min(1,max(0,phase/.69));s=u*u*(3-2*u)
                v=arrival_offsets[k]*(1-s);a.SetPosition(*v)
            else:a.SetVisibility(False)
    plot.render()
    raw=plot.screenshot(return_img=True)
    return draw_overlay(raw,t,bi,phase,active,True)

if args.test:
    ts=[0,INTRO+.4,INTRO+15*BATCH+.65,DURATION-1]
    st=time.time()
    for i,t in enumerate(ts):frame(t).save(args.output/f'test-{i:02d}.png')
    print(json.dumps({'test_frames':len(ts),'seconds':time.time()-st}),flush=True)
else:
    out=args.output/'Haven1_CAD_Assembly_4_Parts.mp4'
    cmd=['ffmpeg','-y','-loglevel','warning','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart','-threads','4',str(out)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE);nf=round(DURATION*FPS);st=time.time()
    samples={int(x*FPS) for x in [3.2,9.6,18.9,29.8,42.8,55.8,65.8,DURATION-1]}
    for i in range(nf):
        t=i/FPS;im=frame(t);proc.stdin.write(im.tobytes())
        if i in samples:im.save(args.output/f'frame-{i:05d}.jpg',quality=92)
        if i==round((DURATION-1)*FPS):im.save(args.output/'Haven1_Assembly_Poster.jpg',quality=94)
        if i%240==0:print(f'frame {i}/{nf}, elapsed {time.time()-st:.1f}s',flush=True)
    proc.stdin.close();assert proc.wait()==0
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(out)]))
    (args.output/'video-verification.json').write_text(json.dumps({'renderer':'PyVista / VTK, original CAD tessellation','host':'falcon-intel','part_count':COUNT,'batch_count':NB,'batch_size':4,'frames':nf,'duration_s':float(probe['format']['duration']),'file_bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'width':W,'height':H,'fps':FPS,'audio':False,'enclosure_transparent':True,'render_seconds':time.time()-st,'source_mesh_sha256':hashlib.sha256(args.source.read_bytes()).hexdigest(),'physics_solved':False},indent=2))
    thumbs=[]
    for f in sorted(args.output.glob('frame-*.jpg')):
        im=Image.open(f);im.thumbnail((640,360));thumbs.append(im)
    sheet=Image.new('RGB',(1280,360*math.ceil(len(thumbs)/2)),BG)
    for k,im in enumerate(thumbs):sheet.paste(im,((k%2)*640,(k//2)*360))
    sheet.save(args.output/'Haven1_Assembly_Contact_Sheet.jpg',quality=92)
    print(json.dumps({'complete':str(out),'frames':nf,'elapsed':time.time()-st}),flush=True)
plot.close()
