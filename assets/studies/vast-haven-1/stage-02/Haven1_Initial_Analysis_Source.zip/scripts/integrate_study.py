"""Publish only this study's verified assets and normalize native outputs for the web viewer."""
from pathlib import Path
import csv,json,shutil,math,hashlib,zipfile

P=Path(__file__).resolve().parents[1]
SITE=P/'website/site';DEST=SITE/'assets/studies/vast-haven-1/stage-02'
SYS=P/'analysis/system-thermal';LOCAL=P/'analysis/local-multiphysics'
s=json.loads((SYS/'summary.json').read_text());m=json.loads((LOCAL/'summary.json').read_text());inp=json.loads((SYS/'inputs.json').read_text())
f=json.loads((LOCAL/'fea/summary.json').read_text())
out={'classification':'Independent assumed-parameter screening; no manufacturer validation or physical tests','system':{'cases':[]},'local':{},'cfd':{}}
notes={
 'baseline':'Assumed full-duty heat loads, 6 m² radiator. All nine assigned component/cabin limits are missed in the final orbit.',
 'larger_radiator':'Same full-duty loads and environment, 10 m² radiator. Battery, payload and cabin still miss their assumed upper limits.',
 'cold_fixed':'Matched cold sensitivity: 50% equipment duty, 80% absorbed environment and 7.2 kW sunlight PV, 10 m² fixed cooling. Battery, cabin and coolant miss their assumed lower limits.',
 'cold_bypass':'Same cold sensitivity (including 7.2 kW sunlight PV) with idealized coolant-to-radiator conductance modulation. All nine assigned limits pass the final orbit. No valve dynamics or measured qualification.'}
comparison=[]
for case in s['cases']:
 if case['id']=='resolution_check':continue
 rows=[]
 with (SYS/case['csv']).open() as fp:
  for row in csv.DictReader(fp):rows.append({k:float(v) for k,v in row.items()})
 assert rows[-1]['time']==86400 and all(math.isfinite(v) for row in rows for v in row.values())
 # Web display uses saved samples. Preserve sample extrema, approximately minute spacing, and event transitions.
 ids={0,len(rows)-1};last=-60
 for i,r in enumerate(rows):
  if r['time']-last>=60:ids.add(i);last=r['time']
  if i and r['sunlight']!=rows[i-1]['sunlight']:ids.update((i-1,i))
 keys=[f'T[{n}]' for n in [1,2,3,4,5,6,9,10,11,13]]+['heaterTotal','powerLoad','powerPV','SOC']
 for key in keys:
  ids.add(min(range(len(rows)),key=lambda i:rows[i][key]));ids.add(max(range(len(rows)),key=lambda i:rows[i][key]))
 selected=[rows[i] for i in sorted(ids)]
 series=[]
 for n in [1,2,3,6,9,10]:
  node=case['nodes'][n-1]
  series.append({'id':f'T{n}','label':node['name'],'unit':'°C','category':'temperature','values':[round(r[f'T[{n}]']-273.15,6) for r in selected]})
 for key,label in [('powerLoad','Total bus demand'),('powerPV','Generated solar power'),('heaterTotal','Heaters'),('powerBatteryHeat','Battery losses')]:
  series.append({'id':key,'label':label,'unit':'W','category':'power','values':[round(r[key],6) for r in selected]})
 series.append({'id':'SOC','label':'Battery state of charge','unit':'%','category':'energy','values':[round(r['SOC']*100,6) for r in selected]})
 out['system']['cases'].append({'id':case['id'],'label':case['name'],'note':notes[case['id']],'time_h':[round(r['time']/3600,9) for r in selected],'series':series,'source_csv':'analysis/system-thermal/'+case['csv']})
 peak=lambda n:next(x['max_C'] for x in case['nodes'] if x['index']==n)
 comparison.append([case['name'],f"{peak(1):.2f}",f"{peak(2):.2f}",f"{peak(3):.2f}",f"{peak(6):.2f}",f"{case['heater_energy_kWh']:.3f}",', '.join(case['unmet_assumed_limits_final_orbit']) or 'None in final orbit'])
out['system']['comparison']={'headers':['Case','Peak avionics °C','Peak battery °C','Peak payload °C','Peak cabin °C','24 h heater kWh','Missed assumed limits'],'rows':comparison}
out['system']['inputs']=[['Mission clock','24 h; t = 0 is assumed sunrise; all nodes start at 20 °C'],['Illumination','Assumed 90 min orbit: 60 min sun, 30 min eclipse; no propagated trajectory'],['Node count','13 lumped thermal states plus electrical storage and energy ledgers'],['Full-duty internal loads','600 W avionics, 800 W payload, 180 W conversion, 450 W ECLSS, 120 W CMGs, 60 W pump, 100 W fans; 480 W crew heat'],['Solar / battery','9 kW available in sunlight; 15 kWh battery; initial SOC 80%; battery charge and discharge efficiency each 95%'],['Radiator trade','6 m² vs 10 m², otherwise matched full-duty case'],['Cold sensitivity','50% equipment duty, 80% absorbed environment and PV availability (7.2 kW), 10 m² radiator; matched fixed vs bypass'],['Bypass representation','Algebraic thermal conductance 10–600 W/K; no resolved coolant hydraulics or actuator delays'],['Surface boundaries','Solar 1,361 W/m², Earth IR 241 W/m², assumed projections and view factors; albedo omitted'],['Assumed temperature targets','Avionics 0–55 °C; battery 10–35 °C; payload 10–40 °C; cabin 18–27 °C'],['Model coupling status','System, local panel and CFD bay are separate screening models; no common hardware heat budget or field exchange yet']]
out['local']['comparison']={'headers':['Controlled study','Baseline','Comparison','Interpretation'],'rows':[
 ['80 W panel peak temperature',f"{m['thermal']['baseline_peak_C']:.2f} °C",f"{m['thermal']['improved_contact_peak_C']:.2f} °C",'Effective cooling/contact coefficient 500 → 2,000 W/(m² K), same 20 °C sink'],
 ['Same temperature field: element stress P95',f"{m['thermostructural']['clamped']['percentile95_von_mises_MPa']:.2f} MPa",f"{m['thermostructural']['sliding']['percentile95_von_mises_MPa']:.2f} MPa",'Ideal both-end clamps → kinematic/sliding restraint'],
 ['Maximum displacement',f"{m['thermostructural']['clamped']['max_displacement_mm']:.3f} mm",f"{m['thermostructural']['sliding']['max_displacement_mm']:.3f} mm",'Reduced restraint permits more motion; real joints and loads remain open'],
 ['Thermal mesh sensitivity','4,608 tetrahedra','15,552 tetrahedra',f"Peak changes {f['mesh']['peak_delta_C']:.3f} °C; two-mesh screening only"],
 ['Clamped peak stress (mesh-sensitive)',f"{m['thermostructural']['clamped']['max_von_mises_MPa']:.2f} MPa",f"{f['mesh']['fine_clamped_max_MPa']:.2f} MPa on finer mesh",'No minimum thickness, flight safety factor or strength acceptance established'] ]}
out['local']['figures']=[{'path':'analysis/local-multiphysics/'+m['thermal']['plot'],'caption':'3D solid conduction: 300 × 200 × 6 mm assumed panel, 80 W, effective contact/cooling coefficient trade; common temperature scale.'},{'path':'analysis/local-multiphysics/'+m['thermostructural']['plot'],'caption':'Same baseline temperature field, different ideal restraints. Colors show through-thickness averaged von Mises stress; annotated maxima are element maxima and are mesh-sensitive.'}]
c=m['cfd'];out['cfd']['cases']=[]
for id,label in [('baseline','12.8 L/s · coarse baseline'),('double_flow','25.6 L/s · matched coarse comparison')]:
 q=c[id]
 out['cfd']['cases'].append({'id':id,'label':label,'metrics':[
  ['Solver',c['solver']],['Geometry / fluid','1.6 × 0.8 × 0.8 m local bay; 20 °C inlet; g = 0'],['Residual heat to air','2 W (separate from the 80 W conduction model)'],['Inlet speed',f"{q['inlet_speed_m_s']:.3f} m/s"],['Volume flow',f"{q['volume_flow_m3_s']*1000:.3f} L/s"],['Flux-weighted outlet',f"{q['outlet_mass_weighted_C']:.5f} °C"],['Heated surface mean',f"{q['heater_area_average_C']:.3f} °C (not mesh-qualified)"],['Short-bay pressure loss',f"{q['pressure_drop_Pa']:.6g} Pa"],['Bay ΔpQ, not fan input',f"{q['air_power_W']*1e6:.3f} µW"],['Cells / SIMPLE iterations',f"{q['cells']:,} / {q['iteration']}"],['Outlet energy error',f"{q['outlet_heat_closure_fraction']:.3g} fraction"]],
 'figures':[{'path':'analysis/local-multiphysics/'+c['velocity_plot'],'caption':'Matched coarse cases: baseline and doubled flow. These are solved OpenFOAM fields in the simplified bay.'},{'path':'analysis/local-multiphysics/'+c['temperature_plot'],'caption':'Matched coarse air-temperature fields. Bulk outlet rise halves. Local surface/hotspot benefit remains below mesh uncertainty.'},{'path':'analysis/local-multiphysics/'+c['pressure_plot'],'caption':'Short-bay static pressure comparison. Filters, ducts, bends, grilles and fan/motor losses are excluded.'}],
 'note':'Steady laminar forced flow with a prescribed local surface heat flux, not conjugate solid/fluid heat transfer. The coarse-grid hotspot reduction (1.03 °C in mean heated surface) is smaller than the baseline coarse-to-fine mesh change (2.53 °C). Flow optimization at the hotspot remains unresolved. This model cannot size a vehicle fan.'})
out['cfd']['mesh']={'headers':['Baseline mesh','Heated mean °C','Outlet °C','Bay Δp Pa'],'rows':[[f"{c[id]['cells']:,}",f"{c[id]['heater_area_average_C']:.3f}",f"{c[id]['outlet_mass_weighted_C']:.6f}",f"{c[id]['pressure_drop_Pa']:.6g}"] for id in ['baseline','mesh_fine','mesh_finer']]}
DEST.mkdir(parents=True,exist_ok=True)
target=DEST/'analysis/system-thermal';target.mkdir(parents=True,exist_ok=True)
for name in ['source','data','plots']:
 shutil.copytree(SYS/name,target/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
for name in ['summary.json','report.md','input-table.csv','inputs.json','cases.json','cad-node-map.json','intel-verification.json','solver.log']:
 shutil.copy2(SYS/name,target/name)
target=DEST/'analysis/local-multiphysics';target.mkdir(parents=True,exist_ok=True)
for name in ['scripts','fea','cfd-flatpanel','verification']:
 if (LOCAL/name).exists():shutil.copytree(LOCAL/name,target/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
for name in ['summary.json','report.md','comparison.csv','Local_Multiphysics_Inputs_Results.zip']:
 shutil.copy2(LOCAL/name,target/name)
(DEST/'study-data.json').write_text(json.dumps(out,separators=(',',':'),allow_nan=False))
(P/'verification/normalized-data-summary.json').write_text(json.dumps({'system_cases':len(out['system']['cases']),'display_samples':[len(x['time_h']) for x in out['system']['cases']],'cfd_cases':len(out['cfd']['cases']),'source':str(SYS/'summary.json'),'data_sha256':hashlib.sha256((DEST/'study-data.json').read_bytes()).hexdigest()},indent=2))
print('Normalized saved simulation outputs:',len(out['system']['cases']),'thermal cases and',len(out['cfd']['cases']),'flow cases')
