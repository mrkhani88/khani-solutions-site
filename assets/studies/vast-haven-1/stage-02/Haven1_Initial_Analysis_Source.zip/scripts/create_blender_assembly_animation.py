"""Save an editable Blender assembly animation from the same CAD part order.

Video delivery uses the original CAD tessellation in VTK with screen-space
labels. This complementary Blender scene preserves all part motion, visibility,
installed positions, timing, transparent enclosure and editable 3D labels.
"""
import bpy, math, json
from pathlib import Path
from mathutils import Vector
B=Path('/home/falcon-admin/projects/vast-haven-1/stage-02-initial-analysis-r1/video')
S=Path('/home/falcon-admin/projects/vast-haven-1/stage-01-cad-r1')
bpy.ops.wm.open_mainfile(filepath=str(S/'cad/Haven1_Public_Reference_R1.blend'))
schedule=json.loads((B/'assembly-timeline.json').read_text())
scene=bpy.context.scene;scene.render.fps=24;scene.frame_start=1;scene.frame_end=round(schedule['duration_s']*24)
for ob in list(scene.objects):
    if ob.type=='FONT':bpy.data.objects.remove(ob,do_unlink=True)
cam=scene.camera;cam.location=(-8,-15,10.5);target=Vector((5.05,0,0));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=16
q=cam.rotation_euler.to_quaternion();right=q@Vector((1,0,0));up=q@Vector((0,1,0))
offsets=[-right*7+up*3,right*6+up*3,-right*5-up*3,right*6-up*2]
mat=bpy.data.materials.new('Assembly label');mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.9,1,1,1);bs.inputs['Emission Color'].default_value=(.6,.9,1,1);bs.inputs['Emission Strength'].default_value=.6
for item in schedule['parts']:
    ob=bpy.data.objects[item['id']];n=item['part_number'];k=(n-1)%4
    f0=round(item['start_s']*24)+1;f1=round(item['settled_s']*24)+1;f2=round(item['label_end_s']*24)
    original=ob.location.copy()
    ob.hide_render=True;ob.hide_viewport=True;ob.keyframe_insert('hide_render',frame=1);ob.keyframe_insert('hide_viewport',frame=1)
    ob.hide_render=False;ob.hide_viewport=False;ob.keyframe_insert('hide_render',frame=f0);ob.keyframe_insert('hide_viewport',frame=f0)
    ob.location=original+offsets[k];ob.keyframe_insert('location',frame=f0)
    ob.location=original;ob.keyframe_insert('location',frame=f1)
    ob.keyframe_insert('location',frame=scene.frame_end)
    if item['transparent']:
        m=ob.data.materials[0].copy();m.name='Transparent '+item['id'];m.use_nodes=True
        bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Alpha'].default_value=.075
        m.diffuse_color=(*m.diffuse_color[:3],.075)
        try:m.surface_render_method='DITHERED'
        except Exception:pass
        ob.data.materials.clear();ob.data.materials.append(m)
    cu=bpy.data.curves.new('Name '+item['id'],'FONT');cu.body=item['name'];cu.size=.15;cu.align_x='CENTER';cu.extrude=0
    name=bpy.data.objects.new('Name '+item['id'],cu);scene.collection.objects.link(name);name.location=Vector(item['installed_center_m'])+up*.6;name.rotation_euler=cam.rotation_euler;name.data.materials.append(mat)
    for frame,hide in [(1,True),(f0,False),(f2,True)]:
        name.hide_render=hide;name.hide_viewport=hide;name.keyframe_insert('hide_render',frame=frame);name.keyframe_insert('hide_viewport',frame=frame)
scene.render.resolution_x=1600;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.world.color=(.03,.05,.09);scene.render.threads_mode='FIXED';scene.render.threads=8
scene.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(B/'Haven1_CAD_Assembly_Animated.blend'))
(B/'blender-animation-verification.json').write_text(json.dumps({'blender_version':bpy.app.version_string,'animated_CAD_objects':221,'batch_size':4,'batch_count':56,'frames':scene.frame_end,'fps':24,'source_scene':str(S/'cad/Haven1_Public_Reference_R1.blend'),'labels':'Editable 3D labels. Delivery movie uses clearer screen-space callouts.','physics_solved':False},indent=2))
print('Saved editable Blender assembly animation with221 original CAD parts.')
