# Haven-1 thermal engineering

## Slide 1

I use a public-reference Haven-1 reconstruction to demonstrate how I would build and challenge a thermal design. The first round includes CAD, native OpenModelica, local solid thermal and thermoelastic FEM, and a separate pressurized-bay CFD exercise. The engineering questions and assumptions are explicit. I would use approved manufacturer requirements and physical test data before hardware decisions.
Sources and method
https://www.vastspace.com/haven-1
https://khanisolutions.com/AISolutions/vast-haven-thermal.html
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 2

Vast develops commercial space stations. Its current Haven-1 page describes two-week missions for four crew, private astronauts and government missions, with a research laboratory and habitation. The public page gives 10.1m height/length,4.4m diameter,80m³ pressurized volume and45m³ habitable volume. Those are exterior and volume anchors. They do not establish hidden packaging or thermal design details. The mission exposes exterior hardware to orbital radiation and eclipse, while interior electronics also depend on controlled cabin air and coolant. Image credit: Vast, official July2026 interior illustration. Company schedules can change and are not used as a simulation input.
Sources and method
https://www.vastspace.com/haven-1
https://vast-public.s3.us-east-1.amazonaws.com/July+2026/0713_Haven-1_Interior+Cutaway_1920x1080.jpg
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 3

The embedded H.264 movie assembles all221 original CAD solids in56batches. The first55batches contain4parts, and the last contains1. Names remain above the CAD with leader lines and disappear at the end of each batch. Enclosure and insulation zones remain transparent. The sequence explains the model hierarchy rather than an actual manufacturing order. The clip lasts80.291667s at24fps. Playback is embedded and starts on this slide in PowerPoint. Click the image to pause or resume. The website is the fallback if the current viewer does not support embedded video.
Sources and method
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#assembly
Stage-02-Initial-Analysis-R1/media/assembly-timeline.json
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 4

I separated the assembly into12groups so direct and indirect heat paths remain visible. The coverage register has25subsystem entries and12interfaces, including energy conversion, batteries, pumps, fans, heaters, sensing, insulation, coolant, gas/water inventories, crew and payload effects. Public hardware photographs support several component functions and counts. The model proposes locations, routing, specific pump quantities, thermal controls and some resource hardware. Colors identify families rather than temperature. Interfaces such as TIM, mount conductance, pump power and cabin heat-exchanger behavior must be characterized for a predictive design.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-01-CAD-R1/sources/thermal-coverage-matrix.md
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-01-CAD-R1/sources/evidence-register.json
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#cad
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 5

The native source and input register assign every numerical input before simulation. The orbit is a rectangular90mincycle with60minsunlight and30mineclipse, repeated for24h. This is not a propagated ephemeris for Haven-1. All13thermalnodes start20°C at sunrise. Thermal capacities and conductances are lumped assumptions. Solar flux is1361W/m² and EarthIR241W/m², while projected areas, optical properties and view factors are assumptions. Albedo is omitted in this round and must be added. Electrical assumptions include 9 kW nominal available sun power, 15 kWh capacity, 80% initial SOC and 95% charge/discharge efficiency. The cold-case environment scale also reduces available solar power to 7.2 kW. The local80WFEM and2WCFD are separate examples with different geometry and boundaries. Their fields are not automatically transferred to the1Dmodel.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/inputs.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/cases.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/report.md
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 6

The native OpenModelica model carries13thermalnodes: avionics,battery,payload,power conversion,ECLSS,cabin,wall,cold plate,coolant,radiator,CMG,solar array andtankresources. Internal conductance links route heat conservatively between these nodes. Exterior radiation includes absorbed solar/IR and emitted energy. The battery ledger carries available solar power, bus loads, charge/discharge losses and curtailment. Proportional heaters protect battery,coolant andresources. Bypass is an algebraic variable conductance of10–600W/K based on coolant temperature14–22°C. It represents controlled heat transfer rather than a solved valve/pipe hydraulic network. This editable diagram shows selected main couplings from the native equations and all13thermalnodes. It is not an OMEdit screenshot and omits minor links for legibility. The native source contains every link. The model does not contain sensor lag, valve dynamics, detailed view-factor geometry or propagated attitude in this round.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/source/Haven1Thermal.mo
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/report.md
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#system
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 7

The matched hot comparison changes only radiator area from6to10m². Larger area increases emission and shifts the heat rejection balance, lowering cold-plate and component temperatures. Exact peaks come from the full-resolution output. Baseline avionics69.788°C,battery59.455°C,payload72.626°C,cabin52.740°C. The10m²case gives45.729,35.555,48.556,30.059°C. It still exceeds the assigned35°Cbattery,40°Cpayload and27°Ccabin limits. These limits are study targets, not disclosed Vast limits. A larger panel is useful but does not close the architecture. Heat loads, interfaces, coating and radiator orientation need further trade studies. Curves use every12th10ssaved sample, retaining start/end. Reported extrema use allsaved samples.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/data/baseline.csv
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/data/larger_radiator.csv
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/summary.json
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 8

This is a matched low-duty/cold-environment comparison. Both cases use10m²radiator,0.5equipment load scale and0.8absorbed environment scale. Those scalings are illustrative and not a worst-case mission definition. The fixed case retains600W/K coolant–radiator conductance. The bypass case modulates10–600W/K with coolant14–22°C. Reducing the connection retains useful internal heat rather than continuously replacing rejected heat with heaters. The control is algebraic with no delay or detailed valve/hydraulic model. The cold-bypass case meets the assigned thermal targets in the final orbit, but this does not qualify it across actual vehicle operating cases.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/data/cold_fixed.csv
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/data/cold_bypass.csv
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/inputs.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/summary.json
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 9

The energy comparison uses the same cold-case hardware and loads except coolant–radiator control. The fixed link consumes8.96684kWh of heater energy over24h, with466.08Wpeak heater demand. Bypass consumes0kWh in this particular nominal example. Zero is conditional on the assigned initial temperature, loads and environment. It does not justify deleting flight heaters. Battery SOC in both cold cases reflects 7.2 kW available solar power in sun, 15 kWh capacity, 80% initial SOC, 95% charge/discharge efficiencies and charge curtailment. Nominal available sun power is 9 kW before the 0.8 environment scale. Thermal and electrical energy ledgers are explicit, including dissipated battery losses. Electrical and thermal accounting must be tested separately against physical power maps.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/data/cold_fixed.csv
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/data/cold_bypass.csv
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/summary.json
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 10

A custom SciPy solver assembles three-dimensional linear tetrahedral thermal finite elements for an assumed Al-like300×200×6mmpanel. The80Wload and20°Ccoolant boundary are imposed study inputs. The comparison changes contact conductance500to2000W/m²K while preserving geometry, load and material properties. Peak temperature falls46.5885to40.0597°C. Better contact reduces the temperature drop into the sink and improves spreading. This is not a detailed electronics or semiconductor-junction model, not actual Vast hardware and not a FreeCAD/CalculiX solved analysis. The source and mesh are provided. Detailed TIM compression, bolt pattern, anisotropy and measured properties remain needed.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/fea/summary.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/scripts/solve_fem.py
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/report.md
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 11

Both restraint cases use exactly the baseline80Wpanel temperature field. Linear-elastic tetrahedral FEM uses an assumed isotropic Al-like material and a stated stress-free reference temperature. Both-end clamping restricts thermal expansion and gives57.2501MPapeak/33.11498MPa95th-percentile stress with0.06392mmmaxmovement. The sliding restraint permits expansion and gives13.0054MPapeak/8.50906MPa95th-percentile stress with0.119579mmmovement. A lower stress trades against more displacement. Constraint peaks and mesh sensitivity need scrutiny, so the95th percentile is shown alongside the maximum. This is an interface screening example, not a launch-load, pressure-vessel, fastener, fatigue or certification analysis. Fastener/preload/contact and real allowable stresses remain unallocated.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/fea/summary.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/report.md
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 12

OpenFOAM buoyantBoussinesqSimpleFoam solves a pressurized1.6×0.8×0.8mbay with a0.4×0.4×0.04melectronics obstruction. Gravity iszero, so buoyancy is absent despite the solver family name. The inlet isuniform0.02or0.04m/s and outlet gauge pressure iszero. No-slip walls and constant-property air withlaminar transport form a screening assumption. The obstruction receives2W over0.224m². This is an intentionally independent low-power demonstration, not the600Wsystem-avionics load or80Wpanel model. The Reynolds numbers and transition/mixing sensitivity must be reviewed before realistic fan design. Velocity maps and streamlines interpolate the saved cell results onto a central plane and are not additional solver cells.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/scripts/build_cfd.py
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/cfd-flatpanel/summary.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/report.md
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 13

This matched comparison doubles inlet speed and holds the2Wsurface heat and20°Cinlet temperature fixed. The table uses saved OpenFOAM results rather than estimating a fan characteristic. The pressure drop and volume flow define fluid power only. Electrical fan power also requires a fan curve and efficiency. The air-cell maximum is not the solid-device temperature. The heater-area-average boundary temperature is a separate wall quantity. The outlet mass-weighted temperature and imposed heat provide an energy-balance check. The low-power laminar example does not establish full-cabin comfort, contaminant removal, flight ventilation performance or actual fan hardware.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/cfd-flatpanel/summary.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/report.md
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 14

Verification checks distinguish equation/numerical consistency from physical validation. The OpenModelica run has a matched5sversus10smaximum-step comparison and an integrated ODE energy ledger. The integrated ledger is an algebraic consistency identity, not independent physical validation. Event-aware exported-power quadrature gives0.018453kWhimbalance at10sversus0.004624kWhat5s. Pre/posteventrowsmustberetainedwhenintegratingpowerdiscontinuities. Local FEM includes mesh refinement, reaction heat and temperature-to-strain transfer, while CFD reports mesh checks, residuals, inlet/outlet mass balance and sensible-heat closure. Mesh-sensitive wall temperatures must remain flagged rather than presented as converged. Small global conservation errors do not prove correct local temperatures. Model inadequacy, unknown power maps, coating/contact data, view factors, airflow transition, sensor/control dynamics and physical testing remain open. Exact values and qualifications are in the native reports.
Sources and method
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/system-thermal/summary.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/fea/summary.json
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-02-Initial-Analysis-R1/analysis/local-multiphysics/cfd-flatpanel/summary.json
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 15

This capability matrix uses Vast’s public Staff Thermal Engineer posting as a reference for discussion. The exact principal-engineer interview requisition has not been supplied or verified, so this is not an exact job-requirement compliance matrix. I distinguish simulation examples, planned tests and unresolved evidence. The simulation package demonstrates my approach to architecture, analytical methods, coupled disciplines, trade studies, numerical checks and technical communication. Relevant real hardware experience should be discussed separately using substantiated employment evidence. This independent study does not imply prior work for Vast.
Sources and method
https://job-boards.greenhouse.io/vast/jobs/4690307006
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#evidence
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 16

I would first build a representative instrumented article with approved materials and repeatable interfaces. Calibrated sensors, individual power channels, coolant/air flow, inlet/sink boundaries and chamber wall conditions define the thermal balance. Interface coupons vary preload and reassembly to quantify contact uncertainty. Vacuum-exposed hardware receives applicable TVAC/thermal-balance tests, while the pressurized cabin bay requires controlled gas/coolant boundaries. Correlation calibrates a bounded parameter set against one dataset, freezes it and predicts held-out cases. Thermal cycling, cold-start, heater/control delays and guarded faults then test recovery and independent protection. Test levels, qualification margins and standards require the actual program authority. No physical measurements or chamber tests have been performed here.
Sources and method
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#validation
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/Vast Haven-1 Thermal Study/Stage-01-CAD-R1/sources/thermal-coverage-matrix.md
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 17

The first round provides a focused roadmap rather than a declaration of an optimized spacecraft. Next thermal work should include actual hot/cold attitude cases, albedo and solar array shadowing, geometric radiation view factors, coating degradation, true power maps and radiator/interface uncertainty. Active-control work needs pump curves, branch pressure losses, valve dynamics, sensor lag, fail positions, independent protection and energy reserve. Local analysis needs ECAD/detail, measured anisotropic materials, fasteners/preload/contact and actual structural load cases. CFD needs realistic fan curves, inlet/outlet design, transition/turbulence and ventilation/contaminant constraints. Only then should calibrated local models feed reductions back into the mission model.
Sources and method
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#system
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#local
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#cfd
https://khanisolutions.com/AISolutions/vast-haven-thermal.html#validation
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.

## Slide 18

Use these links to navigate the engineering discussion without scrolling through the full website. Each main slide also links to its detailed evidence. The downloadable package preserves the public-reference CAD, assembly animation, native Modelica source, full-resolution solver data, finite-element/CFD scripts and reports. The website shows selected saved data rather than launching a new solver run. I would extend the package around the exact requisition, approved hardware inputs and program review priorities.
Sources and method
https://khanisolutions.com/AISolutions/vast-haven-thermal.html
https://job-boards.greenhouse.io/vast/jobs/4690307006
Study scope: independent public-reference interview demonstration. Internal packaging, thermal hardware, materials, properties, power maps and numerical limits include analyst assumptions. This work is not Vast manufacturing CAD, validated vehicle performance, actual employment at Vast or flight qualification. The system, local FEM and local CFD models are separate first-round models. Zero physical tests have been performed in this study.