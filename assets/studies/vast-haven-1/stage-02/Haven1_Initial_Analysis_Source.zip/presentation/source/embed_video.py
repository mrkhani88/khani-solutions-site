"""Add the delivered H.264 assembly movie to an Artifact Tool authored PPTX.

Uses PowerPoint-generated native PresentationML playback timing from the user's
earlier Sceye deck. Video metadata, relationships and duration are remapped to
the new image shape. The media is embedded, with no external file dependency.
"""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree as E
import hashlib,json
R=Path(__file__).resolve().parents[1]
src=R/'.build/Haven1_Interview_Draft.pptx';dst=R/'.build/Haven1_Interview_Candidate.pptx'
vid=R.parent/'media/Haven1_CAD_Assembly_4_Parts.mp4'
timing=R/'source/native-video-timing.xml'
NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships','p14':'http://schemas.microsoft.com/office/powerpoint/2010/main','rel':'http://schemas.openxmlformats.org/package/2006/relationships'}
def tag(p,n):return '{'+NS[p]+'}'+n
with ZipFile(src)as z:files={n:z.read(n)for n in z.namelist()}
x=E.fromstring(files['ppt/slides/slide3.xml']);pic=x.find('.//p:pic',NS);assert pic is not None
cn=pic.find('p:nvPicPr/p:cNvPr',NS);sid=cn.get('id');cn.set('name','Haven-1 CAD assembly, 80 seconds');cn.set('descr','Embedded silent native-geometry assembly video. 221 components in56batches. Public-reference reconstruction.')
click=E.Element(tag('a','hlinkClick'));click.set('action','ppaction://media');cn.insert(0,click)
nv=pic.find('p:nvPicPr/p:nvPr',NS);vf=E.SubElement(nv,tag('a','videoFile'));vf.set(tag('r','link'),'rIdHavenVideo')
extlst=E.SubElement(nv,tag('p','extLst'));ext=E.SubElement(extlst,tag('p','ext'));ext.set('uri','{DAA4B4D4-6D71-4841-9C94-3DE7FCFB9230}')
med=E.SubElement(ext,tag('p14','media'),nsmap={'p14':NS['p14']});med.set(tag('r','embed'),'rIdHavenMedia')
stretch=pic.find('p:blipFill/a:stretch',NS)
if stretch is not None and len(stretch)==0:E.SubElement(stretch,tag('a','fillRect'))
t=E.fromstring(timing.read_bytes())
for n in t.xpath('//*[@spid]'):n.set('spid',sid)
for n in t.xpath('//*[@dur="12000"]'):n.set('dur','80292')
x.append(t);files['ppt/slides/slide3.xml']=E.tostring(x,xml_declaration=True,encoding='utf-8',standalone=True)
rels=E.fromstring(files['ppt/slides/_rels/slide3.xml.rels'])
for rid,kind in [('rIdHavenVideo','http://schemas.openxmlformats.org/officeDocument/2006/relationships/video'),('rIdHavenMedia','http://schemas.microsoft.com/office/2007/relationships/media')]:E.SubElement(rels,tag('rel','Relationship'),Id=rid,Type=kind,Target='../media/Haven1_Assembly.mp4')
files['ppt/slides/_rels/slide3.xml.rels']=E.tostring(rels,xml_declaration=True,encoding='utf-8',standalone=True)
ct=E.fromstring(files['[Content_Types].xml']);cns='http://schemas.openxmlformats.org/package/2006/content-types'
if not ct.xpath('//*[local-name()="Default" and @Extension="mp4"]'):E.SubElement(ct,'{'+cns+'}Default',Extension='mp4',ContentType='video/mp4')
files['[Content_Types].xml']=E.tostring(ct,xml_declaration=True,encoding='utf-8',standalone=True);files['ppt/media/Haven1_Assembly.mp4']=vid.read_bytes()
for n,b in list(files.items()):
 if n.startswith('ppt/') and n.endswith('.xml'):
  el=E.fromstring(b)
  for f in el.xpath('//*[@typeface]'):
   if f.get('typeface')in ['Aptos','Aptos Display','Arial']:f.set('typeface','Arial')
  if '/charts/'in n:
   for title in el.xpath('//*[local-name()="title"]'):
    if not title.xpath('.//*[local-name()="t"]/text()'):title.getparent().remove(title)
  files[n]=E.tostring(el,xml_declaration=True,encoding='utf-8',standalone=True)
with ZipFile(dst,'w',ZIP_DEFLATED)as z:
 for n,b in files.items():z.writestr(n,b)
with ZipFile(dst)as z:assert hashlib.sha256(z.read('ppt/media/Haven1_Assembly.mp4')).digest()==hashlib.sha256(vid.read_bytes()).digest()
record={'candidate':str(dst),'video_sha256':hashlib.sha256(vid.read_bytes()).hexdigest(),'video_bytes':vid.stat().st_size,'slide':3,'shape_id':sid,'embedded':True,'external_file_dependency':False,'native_timing_source':str(timing),'playback':'Automatic start, click toggles pause. Target PowerPoint not tested in this run.','duration_ms':80292}
(R/'.build/media-embedding.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
