from pathlib import Path
import json,numpy as np,pandas as pd
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
R=Path(__file__).resolve().parents[1];S=R/'system';P=R/'plots';P.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False})
names=['Avionics','Battery','Payload','Power conversion','ECLSS','Cabin','Wall','Cold plate','Coolant','Radiator','CMG','Solar array','Tank resources']; bands={0:(0,55),1:(10,35),2:(10,40),5:(18,27)}
cs={};out={}
for n in ['baseline','improved','cold_fixed','cold_bypass','cold_start','flow_fault','flow_protected','power_uncertainty','refined_time']:
 d=pd.read_csv(S/(n+'_res.csv'));cs[n]=d
 ts=[d[f'T[{i}]'].to_numpy()-273.15 for i in range(1,14)]
 out[n]={'nodes':{nm:dict(min_C=float(a.min()),max_C=float(a.max()),final_C=float(a[-1])) for nm,a in zip(names,ts)},'heater_kWh':float(d.energyHeaters.iloc[-1]/3.6e6),'pump_kWh':float(d.energyPump.iloc[-1]/3.6e6),'peak_heater_W':float(d.heaterTotal.max()),'closure_J':float(d.wholeEnergyClosureJ.abs().max()),'completed_s':float(d.time.iloc[-1]),'mean_flow_L_min':float(d.totalFlow.mean()),'mean_pump_W':float(d.pumpW.mean()),'local_peak_estimate_C':float((d['T[9]']-273.15+600*d.effectiveR+(71.3156-20-600*(.035511671675+.000299401242))).max())}
 print(n,[(x,round(out[n]['nodes'][x]['max_C'],2))for x in ['Avionics','Battery','Payload','Cabin']],out[n]['heater_kWh'])
fig,axs=plt.subplots(1,2,figsize=(12,4.3),layout='constrained')
for ax,n in zip(axs,['baseline','improved']):
 d=cs[n]
 for i,c in [(0,'#087f95'),(1,'#ad7a22'),(2,'#4675ad'),(5,'#b34c4c')]:ax.plot(d.time/3600,d[f'T[{i+1}]']-273.15,label=names[i],color=c)
 ax.set(xlabel='Elapsed time [h]',ylabel='Temperature [°C]',title=n);ax.grid(alpha=.2);ax.set_ylim(10,90);ax.legend(fontsize=9,ncol=2)
fig.suptitle('Same station heat budget; CFD/FEM-derived avionics thermal path');fig.savefig(P/'mission.png',dpi=170)
fig,axs=plt.subplots(1,2,figsize=(12,4.3),layout='constrained')
labels=['Avionics','Battery','Payload','Cabin'];limits=[55,35,40,27];x=np.arange(4)
for j,n in enumerate(['baseline','improved']):axs[0].bar(x+(j-.5)*.3,[out[n]['nodes'][a]['max_C']for a in labels],width=.3,label=n,color=['#ad7a22','#087f95'][j])
axs[0].scatter(x,limits,marker='_',s=500,c='#b34c4c',label='Study maximum');axs[0].set_xticks(x,labels);axs[0].set_ylabel('Maximum temperature [°C]');axs[0].legend(fontsize=9)
for j,n in enumerate(['cold_fixed','cold_bypass']):axs[1].bar(j,[out[n]['heater_kWh']][0],color=['#ad7a22','#087f95'][j]);axs[1].text(j,out[n]['heater_kWh']+.1,'%.2f'%out[n]['heater_kWh'],ha='center')
axs[1].set_xticks([0,1],['Fixed radiator link','Controlled bypass']);axs[1].set(ylabel='Heater energy [kWh / 24 h]',title='Matched cold sensitivity')
fig.suptitle('Design comparison: hot limits and cold heater demand');fig.savefig(P/'comparison.png',dpi=170)
fig,axs=plt.subplots(1,2,figsize=(12,4),layout='constrained')
for n in ['improved','cold_start','flow_fault','flow_protected']:
 d=cs[n];axs[0].plot(d.time/3600,d['T[1]']-273.15,label=n);axs[1].plot(d.time/3600,d.heaterTotal,label=n)
axs[0].axhline(55,c='red',ls='--',label='Avionics limit');axs[0].set(ylabel='Avionics bulk temperature [°C]',xlabel='Elapsed time [h]');axs[1].set(ylabel='Heater power [W]',xlabel='Elapsed time [h]')
for ax in axs:ax.legend(fontsize=9);ax.grid(alpha=.2)
fig.suptitle('Off-nominal cases: 5 °C start / 20 s sensor lag / 50% flow loss at 12 h');fig.savefig(P/'robustness.png',dpi=170)
a=cs['improved'].drop_duplicates('time',keep='last');b=cs['refined_time'].drop_duplicates('time',keep='last');err=max(np.max(abs(np.interp(a.time,b.time,b[f'T[{i}]'])-a[f'T[{i}]'])) for i in range(1,14))
out['verification']={'time_step_max_delta_K':float(err),'physical_tests':0,'CFD_mesh_wall_delta_K':.279921165,'CFD_mesh_pressure_change_percent':100*(95.1858157052/91.1008824781-1)}
(R/'system-summary.json').write_text(json.dumps(out,indent=2))
# Architecture drawn directly from solved named nodes and exported reduction relationships.
fig,ax=plt.subplots(figsize=(12,5.4));ax.set(xlim=(0,12),ylim=(0,5.4));ax.axis('off')
boxes={'Avionics / 600 W':(0,3.6),'Battery':(0,2.5),'Payload / 800 W':(0,1.4),'ECLSS / cabin':(0,.3),'Interface + cold plate':(3.2,3.6),'Other cold plates':(3.2,1.4),'Coolant + pump':(6.3,2.5),'Bypass + radiator':(9.4,2.5)}
for label,(x,y) in boxes.items():ax.add_patch(FancyBboxPatch((x+.05,y+.05),2.5,.8,boxstyle='round,pad=.02',facecolor='#e7f2f5',edgecolor='#087f95'));ax.text(x+1.3,y+.45,label,ha='center',va='center',fontsize=10)
for a,b in [('Avionics / 600 W','Interface + cold plate'),('Battery','Other cold plates'),('Payload / 800 W','Other cold plates'),('ECLSS / cabin','Coolant + pump'),('Interface + cold plate','Coolant + pump'),('Other cold plates','Coolant + pump'),('Coolant + pump','Bypass + radiator')]:
 x,y=boxes[a];xx,yy=boxes[b]
 if a=='ECLSS / cabin':
  ax.plot([x+2.6,5.95,5.95],[y+.45,y+.45,yy+.45],color='#587081',lw=1.8);ax.annotate('',xy=(xx,yy+.45),xytext=(5.95,yy+.45),arrowprops=dict(arrowstyle='->',color='#587081',lw=1.8));continue
 ax.annotate('',xy=(xx,yy+.45),xytext=(x+2.6,y+.45),arrowprops=dict(arrowstyle='->',color='#587081',lw=1.8))
ax.text(6,5.05,'Integrated OpenModelica mission model',ha='center',fontsize=19,color='#142b3d');ax.text(6,4.6,'CFD flow maps + 3D FEM thermal resistance; pumps, heaters, power and storage',ha='center',fontsize=11);fig.savefig(P/'architecture.png',dpi=180,bbox_inches='tight')
