from pathlib import Path
import json,re
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]; (R/'plots').mkdir(exist_ok=True)
def last(log,expr):return float(re.findall(expr,log)[-1])
res=[]
for name in ['low','nominal','high','refined']:
 p=R/'cfd'/name;s=(p/'log.solve').read_text();a=json.loads((p/'inputs.json').read_text())
 tw=last(s,r'areaAverage\(heater\) of T = ([\d.eE+-]+)')-273.15;to=last(s,r'weightedAverage\(outlet\) of T = ([\d.eE+-]+)')-273.15
 dp=last(s,r'areaAverage\(inlet\) of p_rgh = ([\d.eE+-]+)')*1000
 qi=last(s,r'sum\(inlet\) of phi = ([\d.eE+-]+)');qo=last(s,r'sum\(outlet\) of phi = ([\d.eE+-]+)')
 res.append(dict(case=name,flow_L_min=a['total_L_min'],wall_mean_C=tw,outlet_C=to,R_K_W=(tw-20)/600,dp_Pa=dp,channel_heat_W=qo*1000*4180*(to-20),mass_error=abs(qi+qo)/qo,converged='SIMPLE solution converged' in s,mesh_OK='Mesh OK.' in (p/'log.checkMesh').read_text(),cells=5760*a['mesh_scale']**3,hydraulic_W=dp*qo*12))
(R/'cfd-summary.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
fig,axs=plt.subplots(1,2,figsize=(12,4),layout='constrained')
for ax,key,label in zip(axs,['wall_mean_C','dp_Pa'],['Mean channel wall [°C]','Channel pressure loss [Pa]']):
 ax.plot([v['flow_L_min'] for v in res[:3]],[v[key] for v in res[:3]],'o-',color='#087f95');ax.scatter([1],[res[3][key]],marker='x',color='#ad7a22',s=100,label='Refined mesh');ax.set(xlabel='Total flow, 12 channels [L/min]',ylabel=label);ax.grid(alpha=.2);ax.legend()
fig.suptitle('OpenFOAM: 600 W, 12 identical parallel water channels, inlet 20 °C');fig.savefig(R/'plots/cfd.png',dpi=160)
# Actual central-width fluid temperature field, nominal case.
p=R/'cfd/nominal'; t=max([x for x in p.iterdir() if x.is_dir() and x.name.isdigit()],key=lambda x:int(x.name))
def vals(name,nc=1):
 s=(t/name).read_text();m=re.search(r'internalField\s+nonuniform\s+List<\w+>\s+(\d+)\s*\(',s); b=s[m.end():s.index(')',m.end())] if nc==1 else s[m.end():s.index('\n)',m.end())];return np.fromstring(b.replace('(',' ').replace(')',' '),sep=' ').reshape(-1,nc)
C=vals('C',3);T=vals('T').ravel()-273.15
mask=abs(C[:,1]-.004)<.00035
fig,ax=plt.subplots(figsize=(12,3),layout='constrained'); im=ax.tricontourf(C[mask,0]*1000,C[mask,2]*1000,T[mask],24,cmap='inferno');fig.colorbar(im,ax=ax,label='Water temperature [°C]');ax.set(xlabel='Channel X [mm]',ylabel='Channel Z [mm]',title='Actual CFD fluid field: 1 L/min total; bottom wall heated');fig.savefig(R/'plots/cfd-field.png',dpi=180)
