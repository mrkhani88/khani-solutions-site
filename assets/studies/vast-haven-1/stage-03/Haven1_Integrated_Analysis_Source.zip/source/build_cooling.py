from pathlib import Path
import json, sys
R=Path(__file__).resolve().parents[1]
def head(cls,obj):
 return f'FoamFile {{ version 2.0; format ascii; class {cls}; object {obj}; }}\n'
for name,lpm,scale in [('low',.5,1),('nominal',1,1),('high',2,1),('refined',1,2)]:
 p=R/'cfd'/name
 for d in ['0','constant','system']: (p/d).mkdir(parents=True,exist_ok=True)
 u=lpm/60000/12/(.008*.002)
 verts=[(0,0,0),(.3,0,0),(.3,.008,0),(0,.008,0),(0,0,.002),(.3,0,.002),(.3,.008,.002),(0,.008,.002)]
 patches=dict(inlet='(0 4 7 3)',outlet='(1 2 6 5)',heater='(0 3 2 1)',walls='(0 1 5 4) (3 7 6 2) (4 5 6 7)')
 (p/'system/blockMeshDict').write_text(head('dictionary','blockMeshDict')+'scale 1; vertices ('+' '.join('(%g %g %g)'%v for v in verts)+'); blocks (hex (0 1 2 3 4 5 6 7) (%d %d %d) simpleGrading (1 1 1)); edges (); boundary ('%(60*scale,12*scale,8*scale)+''.join(k+' {type '+('patch' if k in ['inlet','outlet'] else 'wall')+'; faces ('+v+');}' for k,v in patches.items())+'); mergePatchPairs ();')
 def field(n,cl,di,iv,b):
  (p/'0'/n).write_text(head(cl,n)+f'dimensions {di}; internalField uniform {iv}; boundaryField '+'{'+''.join(k+' {'+b[k]+'}' for k in patches)+'}')
 field('U','volVectorField','[0 1 -1 0 0 0 0]',f'({u} 0 0)',dict(inlet=f'type fixedValue; value uniform ({u} 0 0);',outlet='type zeroGradient;',heater='type noSlip;',walls='type noSlip;'))
 field('p_rgh','volScalarField','[0 2 -2 0 0 0 0]','0',dict(inlet='type zeroGradient;',outlet='type fixedValue; value uniform 0;',heater='type fixedFluxPressure; rho rhok; value uniform 0;',walls='type fixedFluxPressure; rho rhok; value uniform 0;'))
 field('T','volScalarField','[0 0 0 1 0 0 0]','293.15',dict(inlet='type fixedValue; value uniform 293.15;',outlet='type zeroGradient;',heater='type fixedGradient; gradient uniform 34722.2222222222;',walls='type zeroGradient;'))
 field('alphat','volScalarField','[0 2 -1 0 0 0 0]','0',{k:'type calculated; value uniform 0;' for k in patches})
 (p/'constant/g').write_text(head('uniformDimensionedVectorField','g')+'dimensions [0 1 -2 0 0 0 0]; value (0 0 0);')
 (p/'constant/transportProperties').write_text(head('dictionary','transportProperties')+'transportModel Newtonian; nu 1e-6; beta 0.0002; TRef 293.15; Pr 6.966666666667; Prt .85;')
 (p/'constant/turbulenceProperties').write_text(head('dictionary','turbulenceProperties')+'simulationType laminar;')
 old=Path('/home/falcon-admin/projects/vast-haven-1/stage-02-initial-analysis-r1/local-multiphysics/cfd-flatpanel/baseline/system')
 for n in ['fvSchemes','fvSolution']: (p/'system'/n).write_text((old/n).read_text())
 funcs=''
 for obj,patch,op,fields in [('wallT','heater','areaAverage','T'),('outletT','outlet','weightedAverage','T'),('pin','inlet','areaAverage','p_rgh'),('qin','inlet','sum','phi'),('qout','outlet','sum','phi')]:
  funcs+=obj+' {type surfaceFieldValue; libs (fieldFunctionObjects); writeFields false; writeControl timeStep; writeInterval 1; regionType patch; name '+patch+'; operation '+op+'; '+('weightField phi; ' if op=='weightedAverage' else '')+'fields ('+fields+');}\n'
 funcs+='cells {type writeCellCentres; libs (fieldFunctionObjects); executeControl writeTime; writeControl writeTime;}'
 (p/'system/controlDict').write_text(head('dictionary','controlDict')+'application buoyantBoussinesqSimpleFoam; startFrom startTime; startTime 0; stopAt endTime; endTime 6000; deltaT 1; writeControl timeStep; writeInterval 6000; writeFormat ascii; writePrecision 12; writeCompression off; runTimeModifiable false; functions {'+funcs+'}')
 (p/'case.foam').touch(); (p/'inputs.json').write_text(json.dumps(dict(total_L_min=lpm,channels=12,length_m=.3,width_m=.008,height_m=.002,heat_total_W=600,heat_channel_W=50,rho=1000,cp=4180,k=.6,nu=1e-6,inlet_C=20,speed_m_s=u,mesh_scale=scale),indent=2))
print('four coolant cases built')
