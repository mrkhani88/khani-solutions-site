from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).resolve().parents[1];files=[]
for dn in ['source','data','fem','cad','tvac','plots']:
 for p in (r/dn).rglob('*'):
  if p.is_file() and p.suffix.lower() in ['.py','.fcmacro','.csv','.json','.md','.inp','.frd','.log','.npz','.png','.fcstd','.step']:files.append(p)
for p in [r/'README.md',r/'integration.json',r/'system-summary.json',r/'cfd-summary.json',r/'system/solver.log',r/'verification/numerical-checks.json']:files.append(p)
files+=list((r/'system/source').glob('*'))
for name in ['low','nominal','high','refined','high_refined']:
 c=r/'cfd'/name
 for dn in ['0','constant','system']:files+=[p for p in (c/dn).rglob('*') if p.is_file()]
 last=max([p for p in c.iterdir() if p.is_dir() and p.name.isdigit()],key=lambda p:int(p.name));files += [p for p in last.rglob('*') if p.is_file()];files+=list(c.glob('log.*'))
files=sorted(set(files));manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for p in files};z=r/'Haven1_Integrated_Analysis_Source.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as f:
 for p in files:f.write(p,p.relative_to(r))
 f.writestr('MANIFEST.sha256.json',json.dumps(manifest,indent=2))
rec=dict(files=len(files),bytes=z.stat().st_size,sha256=hashlib.sha256(z.read_bytes()).hexdigest());(r/'verification/archive-receipt.json').write_text(json.dumps(rec,indent=2));print(json.dumps(rec))
