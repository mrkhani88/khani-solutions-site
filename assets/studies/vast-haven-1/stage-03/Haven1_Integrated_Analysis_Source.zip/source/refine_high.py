from pathlib import Path
import shutil
r=Path(__file__).resolve().parents[1]/"cfd";p=r/"high_refined";p.mkdir(exist_ok=True)
for d in ["0","constant","system"]:shutil.copytree(r/"refined"/d,p/d,dirs_exist_ok=True)
(p/"0/U").write_text((r/"high/0/U").read_text())
