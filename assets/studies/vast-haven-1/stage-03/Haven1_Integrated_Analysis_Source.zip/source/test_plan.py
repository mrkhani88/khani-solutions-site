from pathlib import Path
import json,numpy as np
from scipy.integrate import solve_ivp
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];D=R/'tvac';D.mkdir(exist_ok=True)
f=json.loads((R/'fem/summary.json').read_text())[2];resistance=(f['mean_C']-20)/600
rows=[];fig,ax=plt.subplots(figsize=(12,4.5),layout='constrained')
for name,shroud,sink in [('Cold balance',223.15,278.15),('Hot balance',323.15,298.15)]:
 def fun(t,y):
  q=300 if t<7200 else 600 if t<18000 else 0
  return [(q-(y[0]-sink)/resistance-.8*.25*5.670374419e-8*(y[0]**4-shroud**4)-.22*(y[0]-293.15))/30000]
 t=np.arange(0,28801,10);sol=solve_ivp(fun,[0,28800],[293.15],t_eval=t,rtol=1e-8,atol=1e-9,max_step=10);ax.plot(t/3600,sol.y[0]-273.15,label=name)
 rows.append(dict(case=name,shroud_K=shroud,coolant_sink_C=sink-273.15,predicted_peak_box_bulk_C=float(sol.y[0].max()-273.15),classification='Simulated pretest prediction, not measured',assumptions='C=30kJ/K; emissivity .8; area .25m2; view1; support+wires .22W/K to20C; 300W0–2h /600W2–5h /off5–8h'))
 np.savetxt(D/(name.replace(' ','_')+'.csv'),np.column_stack([t,sol.y[0]-273.15]),delimiter=',',header='time_s,box_bulk_C',comments='')
ax.set(xlabel='Elapsed test time [h]',ylabel='Predicted box bulk temperature [°C]',title='Proposed TVAC sequence: 300 W / 600 W / power off');ax.legend();ax.grid(alpha=.2);fig.savefig(R/'plots/tvac.png',dpi=160)
(D/'predictions.json').write_text(json.dumps(rows,indent=2))
(D/'Test_Plan.md').write_text('''# Proposed subsystem TVAC readiness package
Status: test planned; zero physical TVAC tests in this study.
## Article and boundaries
Representative 600W avionics spreader/box on liquid cold plate, coolant feedthroughs and support fixture. Evacuated exterior; do not evacuate a pressurized flight box that requires internal air without a qualified pressure design. This is a proposed test article, not a Haven flight assembly.
Temperature-controlled shroud, coolant supply and supports modeled independently. Laboratory gravity retained; fluid orientation effects must be assessed. Chamber pressure requirement, ramp rates, qualification/acceptance levels and cycle count require program/facility approval; none selected as flight requirements here.
## Instrumentation
Calibrated thermocouples/RTDs at heater footprint center, corners, TIM interfaces, coldplate inlet/outlet, mounting feet, fixture and shroud. Log each electrical power channel, coolant mass flow/pressure/temperatures, chamber pressure and functional telemetry. Record sensor attachment, wire routing and calibrated uncertainty; identify instrumentation heat leaks.
## Sequence
Leak/functional and ambient baseline checks; pumpdown with approved limits; controlled hot/cold balance plateaus at low and nominal dissipation; functional checks at plateaus; cold startup, heater control and loss-of-flow protection checks; tailored thermal cycling and post-test inspection. Numerical illustration shows300W2h,600W3h,off3h with10s output. Actual plateau duration follows stability, not the arbitrary illustration clock.
Proposed balance stabilization gate: all designated temperatures change less than0.1K/h over1h, and measured boundary power is stable. This is a proposal requiring tailoring.
## Correlation and uncertainty
Predict sensor values and time constants before test. Record predicted-minus-measured residuals. Estimate bounded contact conductance/emissivity using selected balance cases with traceable property priors. Freeze fitted parameters and predict a withheld power/boundary condition. Proposed development targets: bulk-sensor residualwithin3K and transient timeconstantwithin15%, reviewed against combined measurement/model uncertainty. No claim these are Vast criteria.
## Deliverables
Pretest prediction report, approved procedure and limits, sensor/channel map, configuration and calibration records, original time histories, anomalies and disposition, correlation parameter ledger, held-out comparison and revised requirement verification matrix. No synthetic measurements are used as validation evidence.
''')
# Convert SI CalculiX FRD fields to FreeCAD mm/MPa viewer derivatives. Preserve original FRD.
for fn in ['improved','improved_sliding']:
 src=R/'fem'/(fn+'.frd');section='';new=[]
 for line in src.read_text().splitlines(True):
  if line.startswith('    2C'):section='coords'
  if line.startswith(' -4'):section=line[5:].split()[0]
  if line.startswith(' -3'):section=''
  if line.startswith(' -1') and section in ['coords','DISP','STRESS']:
   prefix=line[:13];vals=[float(line[i:i+12]) for i in range(13,len(line.rstrip()),12)]
   factor=1e-6 if section=='STRESS' else 1000
   vals=[v*factor for v in vals]
   if section=='coords':vals[2]+=12.5
   line=prefix+''.join('%12.5E'%v for v in vals)+'\n'
  new.append(line)
 (R/'fem'/(fn+'_FreeCAD_mm_MPa.frd')).write_text(''.join(new))
print('TVAC predictions and unit-converted viewer fields written')
