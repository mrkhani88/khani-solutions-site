from pathlib import Path
import json,re,numpy as np,pandas as pd
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];S=R/'system';P=R/'plots';out=json.loads((R/'system-summary.json').read_text())
cs={n:pd.read_csv(S/(n+'_res.csv'))for n in out if n!='verification'}
fig,ax=plt.subplots(figsize=(12,4.8),layout='constrained')
for i,label,c in [(1,'Avionics','#087f95'),(2,'Battery','#ad7a22'),(3,'Payload','#4675ad'),(6,'Cabin','#b34c4c')]:ax.plot(cs['baseline'].time/3600,cs['baseline'][f'T[{i}]']-273.15,label=label,color=c)
ax.set(xlabel='Elapsed time from assumed sunrise [h]',ylabel='Temperature [°C]',title='Baseline: 10 m² radiator; 1 L/min avionics branch; original interface');ax.legend(ncol=4);ax.grid(alpha=.2);fig.savefig(P/'baseline.png',dpi=170)
fig,axs=plt.subplots(1,2,figsize=(12,4.4),layout='constrained')
for n,label in [('improved','Nominal'),('cold_start','5 °C start + sensor lag'),('flow_fault','50% flow loss'),('flow_protected','Flow loss + 15% payload shedding')]:
 d=cs[n];axs[0].plot(d.time/3600,d['T[3]']-273.15,label=label);axs[1].plot(d.time/3600,d.heaterTotal,label=label)
axs[0].axhline(40,c='red',ls='--');axs[0].set(ylabel='Payload temperature [°C]',xlabel='Elapsed time [h]');axs[1].set(ylabel='Heater power [W]',xlabel='Elapsed time [h]')
for ax in axs:ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('Fault response: sensor threshold 39.5 °C latches 15% payload shedding');fig.savefig(P/'robustness.png',dpi=170)
# Event-aware quadrature retains duplicate timestamps at discontinuities.
ver=out['verification']
for name in ['improved','refined_time']:
 d=cs[name];stored=np.array([30000,80000,24000,18000,40000,80000,600000,30000,80000,112000,40000,120000,50000]) @ np.column_stack([d[f'T[{i}]']-293.15 for i in range(1,14)]).T
 total=stored+d.batteryEnergy.to_numpy()-d.batteryEnergy.iloc[0];q=d.radiatorSolar+d.radiatorIR+d.wallSolar+d.wallIR+d.arraySolar+d.arrayIR+480-d.radiatorEmission-d.wallEmission-d.arrayEmission
 ver[name+'_quadrature_residual_kWh']=float((total[-1]-np.trapezoid(q,d.time))/3.6e6)
# Local mean model is a bulk surrogate. Compute conservative steady hotspot envelopes with actual inlet/flow.
for n,d in cs.items():
 extra=71.3156-20-600*(.030511671675+.005+.0002994012416666428)
 peak=d['T[9]']-273.15+600*d.effectiveR+extra
 out[n]['local_full_power_steady_envelope_C']=float(peak.max())
 for i,label in [(1,'Avionics'),(2,'Battery'),(3,'Payload'),(6,'Cabin')]:
  band={1:(0,55),2:(10,35),3:(10,40),6:(18,27)}[i];a=d[f'T[{i}]']-273.15
  out[n]['nodes'][label]['first_time_above_min_s']=float(d.time[a>=band[0]].iloc[0]) if any(a>=band[0]) else None
ver['FEM_peak_mesh_delta_K']=.0744
p=R/'cfd/high_refined/log.solve'
if p.exists():
 s=p.read_text();tw=float(re.findall(r'areaAverage\(heater\) of T = ([\d.eE+-]+)',s)[-1])-273.15;dp=float(re.findall(r'areaAverage\(inlet\) of p_rgh = ([\d.eE+-]+)',s)[-1])*1000
 ver['high_flow_refined_wall_C']=tw;ver['high_flow_refined_dp_Pa']=dp;ver['high_flow_refined_wall_delta_K']=tw-38.307003005;ver['high_flow_refined_pressure_delta_percent']=100*(dp/188.127005646-1);ver['high_flow_converged']='SIMPLE solution converged' in s
out['verification']=ver;(R/'system-summary.json').write_text(json.dumps(out,indent=2))
for n,d in cs.items():
 cols=['time']+[f'T[{i}]'for i in range(1,14)]+['heaterTotal','energyHeaters','energyPump','pumpW','pumpHead','totalFlow','branchFlow','effectiveR','payloadFactor','batteryEnergy','wholeEnergyClosureJ'];(R/'data').mkdir(exist_ok=True);d[cols].to_csv(R/'data'/(n+'.csv'),index=False)
print(json.dumps(ver,indent=2))
