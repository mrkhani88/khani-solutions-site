from pathlib import Path
import json,re
R=Path(__file__).resolve().parents[1];S=R/'system';(S/'source').mkdir(parents=True,exist_ok=True)
base=Path('/home/falcon-admin/projects/vast-haven-1/stage-02-initial-analysis-r1/system-thermal/source/Haven1Thermal.mo').read_text()
fem=json.loads((R/'fem/summary.json').read_text());cfd=json.loads((R/'cfd-summary.json').read_text())
rb=(fem[0]['mean_C']-20)/600;ri=(fem[2]['mean_C']-20)/600
extra='''    parameter Real flowDesign=8;
    parameter Real crewPower=480;
    parameter Real branchFraction=.125;
    parameter Real contactR=.02;
    parameter Real sensorTau=1;
    parameter Boolean fault=false;
    parameter Boolean protection=false;
    Real sensedPayload(start=initialK,fixed=true);
    discrete Boolean shed(start=false,fixed=true);
    Real payloadFactor;
    Real sensedCoolant(start=initialK,fixed=true);
    Real totalFlow;
    Real branchFlow;
    Real pumpHead;
    Real channelDP;
    Real pumpW;
    Real fluidR;
    Real effectiveR;
    Real avionicsTransfer;
    Real energyPump(start=0,fixed=true);
'''
base=base.replace('    parameter Real sigma',extra+'    parameter Real sigma',1)
# Remove original avionics-to-coldplate conductance: replacement goes directly to coolant inlet node.
m=re.search(r'parameter Real G\[N,N\]=\[(.*?)\];',base,re.S);rows=[[float(x) for x in r.split(',')]for r in m.group(1).split(';')];rows[0][7]=rows[7][0]=0
base=base[:m.start(1)]+';'.join(','.join(map(str,row)) for row in rows)+base[m.end(1):]
base=base.replace('parameter Real C[N]={30000,80000,24000,18000,40000,80000,600000,30000,80000,70000,40000,120000,50000}', 'parameter Real C[N]={30000,80000,24000,18000,40000,80000,600000,30000,80000,7000*radiatorArea,40000,120000,50000}')
rf=[x['R_K_W'] for x in cfd[:3]];spread=ri-.005-rf[2]
eq=f'''    pumpHead=70000*(flowDesign/8)^2*(if fault and time>43200 then .25 else 1)-35000*(totalFlow/8)^2;
    branchFlow=totalFlow*branchFraction;
    channelDP=if branchFlow<=1 then 44.78496766+(branchFlow-.5)*92.6318296362 else 91.1008824781+(branchFlow-1)*97.0261231679;
    pumpHead=35000*(totalFlow/8)^2+channelDP;
    pumpW=5+pumpHead*totalFlow/60000/.35;
    der(energyPump)=pumpW;
    der(sensedPayload)=(T[3]-sensedPayload)/sensorTau;
    when protection and totalFlow<.75*flowDesign and sensedPayload>312.65 then
      shed=true;
    end when;
    payloadFactor=if shed then .85 else 1;
    der(sensedCoolant)=(T[9]-sensedCoolant)/sensorTau;
    fluidR=if branchFlow<=1 then {rf[0]}+(max(.5,branchFlow)-.5)*({(rf[1]-rf[0])/.5}) else {rf[1]}+(min(2,branchFlow)-1)*({rf[2]-rf[1]});
    effectiveR=fluidR+contactR+{spread};
    avionicsTransfer=(T[1]-T[9])/effectiveR;
'''
base=base.replace('  equation\n    sunlight=', '  equation\n'+eq+'    sunlight=')
base=base.replace('10+590*min(1,max(0,(T[9]-287.15)/8)) else 600','10+(.85*totalFlow/60000*4180000-10)*min(1,max(0,(sensedCoolant-287.15)/8)) else .85*totalFlow/60000*4180000')
base=base.replace('powerLoad=2130*equipmentScale+180*equipmentScale+heaterTotal;','powerLoad=(2130-60)*equipmentScale+180*equipmentScale+heaterTotal+pumpW;').replace('Q[9]=60*equipmentScale+heaterCoolant;','Q[9]=pumpW+heaterCoolant;')
base=base.replace('avionics.Q=Q[1]+','avionics.Q=Q[1]-avionicsTransfer+').replace('coolant.Q=Q[9]+','coolant.Q=Q[9]+avionicsTransfer+')
base=base.replace('4*120+100*equipmentScale','crewPower+100*equipmentScale').replace('+480-radiatorEmission','+crewPower-radiatorEmission')
base=base.replace('Q[3]=800*equipmentScale;', 'Q[3]=800*equipmentScale*payloadFactor;').replace('heaterTotal+pumpW;', 'heaterTotal+pumpW-800*equipmentScale*(1-payloadFactor);')
(S/'source/Haven1Thermal.mo').write_text(base)
cases=[('baseline',10,8,.125,.02,1,1,False,1,False,293.15,10),('improved',16,10,.2,.005,1,1,True,1,False,293.15,10),('cold_fixed',16,10,.2,.005,.8,.5,False,1,False,293.15,10),('cold_bypass',16,10,.2,.005,.8,.5,True,1,False,293.15,10),('cold_start',16,10,.2,.005,.8,.5,True,20,False,278.15,10),('flow_fault',16,10,.2,.005,1,1,True,20,True,293.15,10),('flow_protected',16,10,.2,.005,1,1,True,20,True,293.15,10),('power_uncertainty',16,10,.2,.005,1,1.1,True,1,False,293.15,10),('refined_time',16,10,.2,.005,1,1,True,1,False,293.15,5)]
mos=['loadFile("source/Haven1Thermal.mo");','getErrorString();']
for name,area,q,b,rc,en,load,ctrl,tau,fault,initial,step in cases:
 override=f'radiatorArea={area},flowDesign={q},branchFraction={b},contactR={rc},environmentScale={en},equipmentScale={load},bypassControl={str(ctrl).lower()},sensorTau={tau},fault={str(fault).lower()},initialK={initial},protection={str(name=='flow_protected').lower()},crewPower={0 if name=='cold_start' else 480}'
 mos += [f'simulate(Haven1Thermal.Integrated,stopTime=86400,numberOfIntervals={86400//step},tolerance=1e-7,method="dassl",outputFormat="csv",fileNamePrefix="{name}",simflags="-override={override} -maxStepSize={step}");','getErrorString();']
(S/'source/run.mos').write_text('\n'.join(mos))
(R/'integration.json').write_text(json.dumps(dict(flow_cfd=cfd,fem=fem,spreading_R=spread,case_definitions=cases,limits=['Parallel identical channels; manifolds and maldistribution unresolved','Water constant properties, no boiling/freezing simulation; study operation above freezing','CFD maps valid only 0.5–2 L/min total branch flow','Lumped loop pressure loss 35kPa at8L/min and pump35%efficiency plus5W are assumptions; no selected hardware','Flow is solved from quadratic pump/loop pressure balance plus CFD channel losses; pump curves are assumed, no actuator dynamics or selected hardware','Local CFD and FEM provide a one-way reduced-order map; no simultaneous co-simulation','Other station interfaces remain inherited assumptions; no hardware correlation']),indent=2))
print('System model and seven cases generated')
