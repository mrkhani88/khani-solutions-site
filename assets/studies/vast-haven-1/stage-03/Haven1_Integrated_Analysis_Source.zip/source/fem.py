from pathlib import Path
import numpy as np,json,subprocess,re
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]; D=R/'fem';D.mkdir(exist_ok=True)
cfd=json.loads((R/'cfd-summary.json').read_text()); results=[]
def frd(p,field):
 s=p.read_text(); ss=s.split('-4  '+field)[-1];ss=re.split(r'\n -3(?:\n|$)',ss)[0]; a=[]
 for l in ss.splitlines():
  if l.startswith(' -1'):a.append([float(x.replace('D','E')) for x in re.findall(r'[-+]?\d*\.\d+E[-+]\d+',l[13:])])
 return np.array(a)
for name,nx,ny,nz,rc in [('baseline',24,16,2,.02),('interface_only',24,16,2,.005),('improved',24,16,2,.005),('refined',36,24,3,.005)]:
 flowcase=cfd[1] if name in ['baseline','interface_only'] else cfd[2]; rf=flowcase['R_K_W'];h=1/(.06*(rc+rf))
 xyz=np.array([(x,y,z) for z in np.linspace(0,.006,nz+1) for y in np.linspace(0,.2,ny+1) for x in np.linspace(0,.3,nx+1)])
 ix=lambda i,j,k:k*(ny+1)*(nx+1)+j*(nx+1)+i+1
 elems=[];top=[];bot=[]
 for k in range(nz):
  for j in range(ny):
   for i in range(nx):
    v=[ix(i,j,k),ix(i+1,j,k),ix(i+1,j+1,k),ix(i,j+1,k),ix(i,j,k+1),ix(i+1,j,k+1),ix(i+1,j+1,k+1),ix(i,j+1,k+1)];elems.append(v);eid=len(elems)
    if k==0:bot.append(eid)
    if k==nz-1 and .075<(i+.5)*.3/nx<.225 and .05<(j+.5)*.2/ny<.15:top.append(eid)
 head='*HEADING\nRepresentative 600W avionics spreader; SI units, assumed Al-like properties\n*NODE\n'+''.join(f'{i+1},{x},{y},{z}\n' for i,(x,y,z) in enumerate(xyz))+'*ELEMENT,TYPE=C3D8,ELSET=ALL\n'+''.join(str(i+1)+','+','.join(map(str,e))+'\n' for i,e in enumerate(elems))+'*MATERIAL,NAME=AL\n*CONDUCTIVITY\n167\n*ELASTIC\n69e9,.33\n*EXPANSION,ZERO=20\n23e-6\n*SOLID SECTION,ELSET=ALL,MATERIAL=AL\n'
 text=head+'*STEP\n*HEAT TRANSFER,STEADY STATE\n*DFLUX\n'+''.join(f'{e},S2,{600/(len(top)*.3/nx*.2/ny)}\n' for e in top)+'*FILM\n'+''.join(f'{e},F1,20,{h}\n' for e in bot)+'*NODE FILE\nNT\n*EL FILE\nHFL\n*END STEP\n'
 p=D/name;p.with_suffix('.inp').write_text(text)
 with p.with_suffix('.log').open('w') as f:subprocess.run(['ccx',name],cwd=D,stdout=f,stderr=subprocess.STDOUT,check=True)
 T=frd(p.with_suffix('.frd'),'NDTEMP').ravel();assert len(T)==len(xyz),(len(T),len(xyz))
 struct=[]
 for mount in ['clamped','sliding']:
  fixed=[]
  for i,(x,y,z) in enumerate(xyz):
   if mount=='clamped' and (abs(x)<1e-10 or abs(x-.3)<1e-10): fixed.append(f'{i+1},1,3,0\n')
   if mount=='sliding' and abs(x)<1e-10:fixed.append(f'{i+1},1,1,0\n')
  if mount=='sliding':fixed += ['1,2,3,0\n',f'{ix(0,ny,0)},3,3,0\n']
  sn=name+'_'+mount;sp=D/sn
  sp.with_suffix('.inp').write_text(head+'*INITIAL CONDITIONS,TYPE=TEMPERATURE\n'+''.join(f'{i+1},20\n' for i in range(len(xyz)))+'*BOUNDARY\n'+''.join(fixed)+'*STEP\n*STATIC\n*TEMPERATURE\n'+''.join(f'{i+1},{t}\n' for i,t in enumerate(T))+'*NODE FILE\nU\n*EL FILE\nS\n*END STEP\n')
  with sp.with_suffix('.log').open('w') as f:subprocess.run(['ccx',sn],cwd=D,stdout=f,stderr=subprocess.STDOUT,check=True)
  U=frd(sp.with_suffix('.frd'),'DISP');S=frd(sp.with_suffix('.frd'),'STRESS');vm=np.sqrt(.5*((S[:,0]-S[:,1])**2+(S[:,1]-S[:,2])**2+(S[:,2]-S[:,0])**2)+3*(S[:,3:]**2).sum(axis=1))/1e6
  struct.append(dict(mount=mount,stress_p95_MPa=float(np.quantile(vm,.95)),max_nodal_stress_MPa=float(vm.max()),max_displacement_mm=float(np.linalg.norm(U,axis=1).max()*1000)))
  if name=='improved':np.savez(D/(sn+'.npz'),xyz=xyz,T=T,U=U,vm=vm)
 np.savez(D/(name+'.npz'),xyz=xyz,elems=np.array(elems),T=T)
 results.append(dict(case=name,flow_L_min=flowcase['flow_L_min'],R_fluid_K_W=rf,R_TIM_K_W=rc,h_effective_W_m2K=h,nodes=len(xyz),elements=len(elems),peak_C=float(T.max()),mean_C=float(T[np.array(elems)-1].mean()),heat_rejected_W=float(h*.3/nx*.2/ny*sum(T[np.array(elems)[e-1,:4]-1].mean()-20 for e in bot)),structure=struct))
(D/'summary.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
fig,axs=plt.subplots(1,2,figsize=(12,4),layout='constrained')
for ax,n in zip(axs,['baseline','improved']):
 a=np.load(D/(n+'.npz'));X=a['xyz'];m=np.isclose(X[:,2],.006);im=ax.tricontourf(X[m,0]*1000,X[m,1]*1000,a['T'][m],levels=np.linspace(20,100,25),cmap='inferno',extend='max');ax.set(xlabel='X [mm]',ylabel='Y [mm]',title=n+'; peak %.1f °C'%a['T'].max());ax.set_aspect('equal')
fig.colorbar(im,ax=axs,label='Solid temperature [°C]');fig.suptitle('CalculiX 3D thermal: 600 W, coolant inlet 20 °C');fig.savefig(R/'plots/fem.png',dpi=160)
fig,axs=plt.subplots(1,2,figsize=(12,4),layout='constrained')
for ax,n in zip(axs,['clamped','sliding']):
 a=np.load(D/('improved_'+n+'.npz'));X=a['xyz'];m=np.isclose(X[:,2],.006);im=ax.tricontourf(X[m,0]*1000,X[m,1]*1000,a['vm'][m],levels=np.linspace(0,100,25),cmap='magma',extend='max');ax.set(xlabel='X [mm]',ylabel='Y [mm]',title=n+' mount');ax.set_aspect('equal')
fig.colorbar(im,ax=axs,label='Extrapolated nodal von Mises [MPa]');fig.suptitle('CalculiX thermoelasticity: same improved temperature field');fig.savefig(R/'plots/stress.png',dpi=160)
