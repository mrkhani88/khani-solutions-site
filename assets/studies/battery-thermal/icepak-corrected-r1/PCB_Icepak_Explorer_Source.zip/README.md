# Public Icepak PCB explorer

Independent Khani Solutions illustrative study.

Preview: extract this ZIP, then run `python3 -m http.server 8000` in its root. Open http://127.0.0.1:8000/AISolutions/battery-thermal-icepak.html .

The HTML contains the exact saved component data. The PNGs are retained native contour images, not transient fields or live CFD. Analytical sliders change only the explicitly labeled Q/(hA) estimate. Volume maxima, vertex averages and surface legend extrema are different statistics.

The companion report and native solver archives are separate downloads on the public study page. The source archive includes a self-contained copy of the interactive controls, data and contour images; portfolio navigation links resolve on khanisolutions.com.

No car-project files are included.
