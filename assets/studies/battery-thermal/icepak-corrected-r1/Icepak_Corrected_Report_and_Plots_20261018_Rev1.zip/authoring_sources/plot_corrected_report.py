from pathlib import Path
import json,csv,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyBboxPatch,FancyArrowPatch
ROOT=Path(__file__).parent; OUT=ROOT/'corrected_report_20261018'; EV=OUT/'evidence'; IM=OUT/'images'
F=json.loads((EV/'report_facts.json').read_text()); CFG=F['configuration']
OLD=json.loads((ROOT/'report_20261018/evidence/report_facts.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#22374b','text.color':'#172c3d','axes.titleweight':'bold','figure.facecolor':'white','savefig.facecolor':'white'})
def save(fig,name):
    fig.savefig(IM/(name+'.png'),dpi=220,bbox_inches='tight');fig.savefig(IM/(name+'.svg'),bbox_inches='tight');plt.close(fig)
labels={'Battery_Cell':'Battery','Processor_Package':'Processor package','Display_Layer':'Display layer','PMIC_Package':'PMIC package','Memory_Package':'Memory package','Camera_Module':'Camera module','Rear_Cover':'Rear cover','Display_Glass':'Display glass','Main_PCB':'Main PCB'}
order=['Processor_Package','Display_Layer','PMIC_Package','Camera_Module','Memory_Package','Battery_Cell']
fig,ax=plt.subplots(figsize=(10.8,5.3));y=np.arange(len(order)); vals=[F['maxima_C'][n] for n in order]
ax.barh(y,vals,color=['#c5543b','#bc704a','#af8453','#628b8f','#628b8f','#338a76'],height=.58)
for i,v in enumerate(vals):ax.text(v+.8,i,f'{v:.1f}°C',va='center',fontweight='bold')
ax.set_yticks(y,[labels[n] for n in order]);ax.invert_yaxis();ax.set_xlim(0,88);ax.set_xlabel('Saved component maximum temperature (°C)');ax.axvline(25,color='#34495e',ls='--',lw=1,label='Ambient 25°C');ax.set_title('Corrected steady-state component maxima',loc='left',pad=20);ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True);ax.legend(loc='lower right',frameon=False);fig.tight_layout();save(fig,'component_maxima')
fig,ax=plt.subplots(figsize=(10.8,5.3));order2=['Rear_Cover','Display_Glass','Display_Layer','Battery_Cell','Main_PCB','Processor_Package','PMIC_Package','Memory_Package','Camera_Module'];y=np.arange(len(order2))
ax.scatter([F['monitor_end_C'][n] for n in order2],y,s=85,c='#226c8c',label='Vertex-average monitor',zorder=3)
for i,n in enumerate(order2):
    if n in F['maxima_C']:
        ax.plot([F['monitor_end_C'][n],F['maxima_C'][n]],[i,i],color='#96a4b0',lw=2);ax.scatter(F['maxima_C'][n],i,s=75,c='#c5543b',marker='D',zorder=3,label='Saved volume maximum' if n=='Display_Layer' else None)
ax.set_yticks(y,[labels[n] for n in order2]);ax.invert_yaxis();ax.set_xlim(45,80);ax.set_xlabel('Temperature (°C)');ax.set_title('Average monitor and maximum are different statistics',loc='left',pad=20);ax.grid(axis='x',alpha=.2);ax.legend(loc='lower right',frameon=False,fontsize=10);fig.tight_layout();save(fig,'component_monitor_vs_maximum')
oldres=np.array(list(csv.reader((ROOT/'report_20261018/evidence/recorded_energy_residual.csv').open()))[1:],dtype=float)
fig,(ax1,ax2)=plt.subplots(1,2,figsize=(11,4.7),gridspec_kw={'width_ratios':[1.65,1]})
ax1.semilogy(oldres[:,0],oldres[:,1],color='#b66b5b',lw=1.7);ax1.axhline(1e-8,color='#173f52',ls='--');ax1.set_ylim(1e-9,max(oldres[:,1])*2);ax1.set_xlabel('Outer iteration');ax1.set_ylabel('Energy residual');ax1.set_title('Original run: target not met',loc='left',fontsize=13);ax1.grid(alpha=.16)
ax2.scatter([1],[F['energy_residual']],s=110,c='#238777',zorder=3);ax2.axhline(1e-8,color='#173f52',ls='--',label='Target 1 × 10⁻⁸');ax2.set_yscale('log');ax2.set_ylim(1e-9,1e-7);ax2.set_xlim(.6,1.4);ax2.set_xticks([1]);ax2.set_xlabel('Outer iteration');ax2.set_title('Corrected run: target met',loc='left',fontsize=13);ax2.text(1,4.2e-9,'6.8952 × 10⁻⁹',ha='center',fontweight='bold');ax2.legend(loc='upper right',frameon=False,fontsize=9);ax2.grid(alpha=.16)
fig.suptitle('Saved solver residuals - no simulated time axis',x=.04,ha='left',fontweight='bold',fontsize=16);fig.tight_layout(rect=[0,0,1,.92]);save(fig,'energy_residual_comparison')
heatparts=[p for p in CFG['parts'] if p['power_w']>0];heatparts.sort(key=lambda x:-x['power_w'])
fig,ax=plt.subplots(figsize=(10.8,4.7));y=np.arange(len(heatparts));ax.barh(y,[p['power_w'] for p in heatparts],color='#3c7e93',height=.6)
for i,p in enumerate(heatparts):ax.text(p['power_w']+.04,i,f"{p['power_w']:.1f} W ({p['power_w']/5.5:.1%})",va='center')
ax.set_yticks(y,[labels[p['name']] for p in heatparts]);ax.invert_yaxis();ax.set_xlim(0,3.3);ax.set_xlabel('Prescribed total heat generation (W)');ax.set_title('Six heat sources total 5.5 W',loc='left',pad=20);ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True);fig.tight_layout();save(fig,'heat_inputs')
fig,(ax1,ax2)=plt.subplots(1,2,figsize=(11,4.4));ax1.bar(['Original','Corrected'],[25876,671368],color=['#ae7a6c','#327c92'],width=.5)
for i,v in enumerate([25876,671368]):ax1.text(i,v+14000,f'{v:,}',ha='center',fontweight='bold')
ax1.set_ylim(0,760000);ax1.set_ylabel('Mesh cells');ax1.set_title('25.95× more cells',loc='left',fontsize=13);ax1.ticklabel_format(axis='y',style='plain');ax1.grid(axis='y',alpha=.13);ax1.set_axisbelow(True)
ax2.bar(['Original','Corrected'],[.3,.05],color=['#ae7a6c','#327c92'],width=.5);ax2.set_ylim(0,.36);ax2.set_ylabel('Requested maximum Z element size (mm)');ax2.set_title('Finer thickness resolution',loc='left',fontsize=13)
for i,v in enumerate([.3,.05]):ax2.text(i,v+.01,f'{v:.2f} mm',ha='center',fontweight='bold')
ax2.grid(axis='y',alpha=.13);ax2.set_axisbelow(True);fig.tight_layout();save(fig,'mesh_comparison')
fig,ax=plt.subplots(figsize=(11,5));h=np.linspace(3,15,160);a=.02776;ax.plot(h,25+5.5/(h*a),lw=2.4,c='#327c92',label='5.5 W');ax.plot(h,25+6.875/(h*a),lw=2,c='#c0793c',ls='--',label='6.875 W (+25%)')
screen=[]
for label,q,hh in [('Weaker cooling',5.5,3.5),('Nominal assumption',5.5,7),('Stronger cooling',5.5,14),('Higher heat input',6.875,7)]:
    v=25+q/(hh*a);screen.append({'case':label,'heat_W':q,'h_W_m2K':hh,'area_m2':a,'ambient_C':25,'isothermal_skin_estimate_C':v,'method':'Analytical energy balance only; not an Icepak simulation'})
    ax.scatter(hh,v,c='#327c92' if q==5.5 else '#c0793c',s=60);ax.annotate(f'{v:.1f}°C',(hh,v),xytext=(7,8),textcoords='offset points',fontsize=10)
ax.set_xlabel('Assumed external cooling coefficient h (W/m²K)');ax.set_ylabel('Isothermal surface estimate (°C)');ax.set_title('Analytical cooling screen: T = 25 + Q / (hA)',loc='left',pad=18);ax.grid(alpha=.16);ax.legend(frameon=False);ax.text(.99,.96,'Not solved Icepak scenarios\nNot component or hot-spot predictions',transform=ax.transAxes,ha='right',va='top',fontsize=10,color='#7a5432');fig.tight_layout();save(fig,'analytical_cooling_screen')
with (EV/'analytical_screening_not_simulations.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=screen[0].keys());w.writeheader();w.writerows(screen)
fig,axs=plt.subplots(1,2,figsize=(11,7),gridspec_kw={'width_ratios':[1,1.2]});ax=axs[0];ax.add_patch(Rectangle((0,0),75,160,facecolor='#eef2f4',edgecolor='#617684',lw=2))
for n in ['Battery_Cell','Main_PCB','Processor_Package','PMIC_Package','Memory_Package','Camera_Module','Copper_Spreader']:
    p=next(x for x in CFG['parts'] if x['name']==n);x,y,z=p['xyz'];dx,dy,dz=p['size'];ax.add_patch(Rectangle((x,y),dx,dy,facecolor=np.array(p['color'])/255,edgecolor='#364b5a',alpha=.8,lw=1.2))
for text,x,y in [('Battery\n65 × 108 mm',37,60),('Main PCB',37,150),('Processor',19,135),('PMIC',40,134),('Memory',51,131),('Camera',56,147)]:ax.text(x,y,text,ha='center',va='center',fontsize=8.5,color='white' if text.startswith('Battery') or text=='Main PCB' else '#111')
ax.set_aspect('equal');ax.set_xlim(-3,78);ax.set_ylim(-3,163);ax.set_xlabel('X (mm)');ax.set_ylabel('Y (mm)');ax.set_title('Input-based plan view',loc='left');ax.spines[['top','right']].set_visible(False)
ax=axs[1];ax.axis('off');layers=[('Display glass',7.2,.8,'#76aac6'),('Display layer',6.6,.6,'#5b879d'),('Spreader/display pad',3.9,2.7,'#b690bf'),('Copper spreader',3.6,.3,'#bf8a49'),('Processor TIM',3.4,.2,'#9d7baa'),('Processor package',2.4,1.,'#cf7759'),('Main PCB',1.6,.8,'#467f68'),('PCB TIM',1.4,.2,'#9d7baa'),('Midplate',.8,.6,'#9caeb9'),('Rear cover',0,.8,'#748e9e')]
for i,(n,z,t,c) in enumerate(layers):
    yy=10-i;ax.add_patch(Rectangle((0,yy),1.25,.63,facecolor=c,edgecolor='white'));ax.text(1.42,yy+.32,f'{n}  |  {t:g} mm',va='center',fontsize=10)
ax.set_xlim(-.2,5.5);ax.set_ylim(.2,11.2);ax.set_title('Processor heat path through the stack',loc='left');ax.text(0,.35,'Layer heights are schematic, not to scale.\nBattery path: cell → battery TIM → midplate → rear cover.',fontsize=10)
fig.suptitle('Illustrative 75 × 160 × 8 mm assembly',x=.06,ha='left',fontweight='bold',fontsize=17);fig.tight_layout(rect=[0,0,1,.94]);save(fig,'model_layout_and_stack')
F['analytical_screening']=screen;F['native_surface_display_maxima_C']={'Battery':54.359,'Electronics_selection':73.971,'Exterior_selection':72.231};F['mesh_mapping_physical_objects']=19;F['mesh_mapping_note']='All 19 physical object names and the 18 cooling face IDs appear in generated grid_mapping. This is not a mesh-independence or per-layer quality check.'
(EV/'report_facts.json').write_text(json.dumps(F,indent=2));print('Generated 7 PNG/SVG plot pairs and analytical CSV')
