from pathlib import Path
import json,shutil,hashlib,zipfile,datetime,re
from pypdf import PdfReader
ROOT=Path(__file__).parent; OUT=ROOT/'corrected_report_20261018'; EV=OUT/'evidence'; SNAP=EV/'saved_run_snapshot'; R=SNAP/'Illustrative_Phone_Corrected.aedtresults'/'IcepakDesign1.results'
SMALL=EV/'native_run_evidence';SMALL.mkdir(exist_ok=True)
for p in R.iterdir():
    if p.is_file() and p.suffix in ['.profile','.SOV','.sd']:shutil.copy2(p,SMALL/p.name)
for name in ['current.uns_out','current.uns_in','current.iter','current.zinfo']:
    shutil.copy2(R/'DV68_S108_V131.restart'/name,SMALL/name)
shutil.copy2(R/'DV68_S108_Meshes0_V0.sd'/'grid_mapping',SMALL/'grid_mapping')
for name in ['original_inputs_unchanged.json','exterior_cooling_face_audit.json']:
    shutil.copy2(SNAP/name,EV/name)
native=OUT/'native_model';native.mkdir(exist_ok=True);shutil.copy2(SNAP/'Illustrative_Phone_Corrected.aedt',native/'Illustrative_Phone_Corrected.aedt')
(native/'README.txt').write_text('This compact package includes the native model input file only. The separate full native archive includes its matching .aedtresults directory and saved fields. Do not interpret a missing result directory in this compact package as a missing original solve.\n')
facts=json.loads((EV/'report_facts.json').read_text());assert facts['energy_residual']<facts['energy_target'];assert abs(facts['maxima_C']['Battery_Cell']-54.3289)<1e-6
pdf=OUT/'Icepak_Phone_Corrected_Thermal_Report_Rev1.pdf';reader=PdfReader(str(pdf));assert len(reader.pages)==15
text='\n'.join(p.extract_text() for p in reader.pages);assert '54.33' in text and '74.51' in text and 'string_length' in text
html=(OUT/'index.html').read_text();refs=re.findall(r'(?:src|href)="([^"]+)"',html);missing=[r for r in refs if not r.startswith(('#','http')) and not (OUT/r).is_file()];assert not missing,missing
readme='''ICEPAK CORRECTED PHONE THERMAL REPORT - REV 1
Completed mesh and solve: 18 October 2026.

START HERE
Open Icepak_Phone_Corrected_Thermal_Report_Rev1.pdf or index.html.
HTML images use relative links and work after unzipping the whole package.
The images folder includes native Icepak contours and mesh, plus PNG/SVG charts.
The evidence folder includes CSV data, machine-readable facts, solver records,
input inventory, boundary audit and SHA256 manifests.

RESULTS
Battery saved maximum: 54.3289 C.
Processor package saved maximum: 74.50522 C (not junction temperature).
Mesh: 671,368 cells; energy residual 6.8952e-9, target 1e-8.
Monitors are Vertex Average, not volume average.
Surface display extrema differ from saved volume maxima; see PDF captions.

QUALIFICATION
Run completed. Results remain provisional: investigate initialization diagnostic,
verify global heat balance, inspect local mesh quality, compare a refined mesh,
and replace illustrative inputs with confirmed data before engineering use.
No new simulations were started for this report. Cooling comparisons are
analytical estimates only, not Icepak cases. The previous 5000 K capped run
is invalid and is not a performance baseline. This report supersedes the
old report for current corrected-run temperatures; originals are preserved.

PACKAGE CONTENTS
Compact ZIP: report, HTML, all figures, inputs, small raw evidence, native input.
Full native ZIP: all of the above plus evidence/saved_run_snapshot containing
the copied .aedt project and matching .aedtresults tree. Open that project
in AEDT for saved field access. The snapshot predates the report-only plots;
use the native script in authoring_sources to recreate contour exports.
Historical readiness/status files predate the successful user-performed run.

MAC USE
Download the ZIP using the private Google Drive link from this chat and unzip.
Suggested destination from the earlier transfer:
/Users/reza/Library/Mobile Documents/com~apple~CloudDocs/Khani Workspace/Projects/PCB Icepak Website Integration/Incoming/
The Windows agent cannot verify that destination has been written on the Mac.
No public sharing permission was added. No Ansys installation is needed to
view PDF/HTML/PNG/CSV. Native saved fields require compatible AEDT software.
'''
(OUT/'README.txt').write_text(readme)
author=OUT/'authoring_sources';author.mkdir(exist_ok=True)
for name in ['collect_corrected_report.py','native_corrected_postprocess.py','create_corrected_contours.py','export_corrected_summary.py','plot_corrected_report.py','build_corrected_report.py','package_corrected_report.py','build_phone_icepak.py','repair_phone_native.py','finalize_repair_ready.py']:
    shutil.copy2(ROOT/name,author/name)
manifest=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and 'qa_render' not in p.parts and 'saved_run_snapshot' not in p.parts and p.name!='package_sha256_manifest.json':manifest.append({'path':str(p.relative_to(OUT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(EV/'package_sha256_manifest.json').write_text(json.dumps(manifest,indent=2))
archives=[]
for full,name in [(False,'Icepak_Corrected_Report_and_Plots_20261018_Rev1.zip'),(True,'Icepak_Corrected_Full_Native_20261018_Rev1.zip')]:
    dest=ROOT/name
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(OUT.rglob('*')):
            if not p.is_file() or 'qa_render' in p.parts or (not full and 'saved_run_snapshot' in p.parts):continue
            z.write(p,str(p.relative_to(OUT)))
    with zipfile.ZipFile(dest) as z:assert z.testzip() is None;count=len(z.infolist())
    archives.append({'path':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':count,'includes_full_saved_native_results':full})
audit={'created':datetime.datetime.now().isoformat(),'pdf_pages':len(reader.pages),'html_relative_links_verified':True,'zip_crc_verified':True,'new_simulations_started':0,'archives':archives}
(ROOT/'corrected_report_package_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
