import json,os,re,hashlib,datetime,shutil
import build_phone_icepak as b
latest=json.load(open(os.path.join(b.ROOT,'latest_repair.json')))
folder=latest['folder'];pf=latest['project'];s=json.load(open(os.path.join(folder,'repair_status.json')))
app=b.desktop();p=app.GetActiveProject();d=p.GetActiveDesign();e=d.SetActiveEditor('3D Modeler')
assert p.GetName()=='Illustrative_Phone_Corrected'
assert os.path.normcase(os.path.normpath(p.GetPath()))==os.path.normcase(folder)
faces=json.load(open(os.path.join(folder,'exterior_cooling_face_audit.json')))
boundary_module=d.GetModule('BoundarySetup')
expected_face_ids=sorted(x['face_id'] for x in faces['faces'])
actual_face_ids=sorted(int(x) for x in boundary_module.GetAssignment('External_Convection'))
if actual_face_ids!=expected_face_ids:
    boundary_module.Reassign(['NAME:External_Convection','Faces:=',expected_face_ids])
assert sorted(int(x) for x in boundary_module.GetAssignment('External_Convection'))==expected_face_ids
setups=list(d.GetModule('AnalysisSetup').GetSetups())
assert setups==['Phone_Steady_Corrected'],setups
assert list(d.GetModule('FieldsReporter').GetFieldPlotNames())==[]
assert int(d.ValidateDesign())==1
p.Save()
text=open(pf,encoding='utf-8',errors='replace').read()
parts=json.load(open(os.path.join(os.path.dirname(s['source_project']),'input_snapshot.json')))
for part in parts['parts']:
    assert part['name'] in list(e.GetObjectsInGroup('Solids'))
    assert e.GetPropertyValue('Geometry3DAttributeTab',part['name'],'Material').strip('"')==part['material']
boundary=re.search(r"\$begin 'External_Convection'(.*?)\$end 'External_Convection'",text,re.S).group(1)
face_ids=[int(x.strip()) for x in re.search(r'Faces\((.*?)\)',boundary).group(1).split(',')]
faces=json.load(open(os.path.join(folder,'exterior_cooling_face_audit.json')))
assert sorted(face_ids)==sorted(x['face_id'] for x in faces['faces'])
assert len(face_ids)==18 and abs(faces['total_area_m2']-.02776)<1e-10
assert "'Heat Transfer Coefficient'='7w_per_m2kel'" in boundary
assert "'Reference Temperature'='25cel'" in boundary
assert "MaxElementSizeX='2mm'" in text and "MaxElementSizeY='2mm'" in text and "MaxElementSizeZ='0.05mm'" in text
assert "MinGapZ='0.01mm'" in text and 'EnableMLM=false' in text
assert text.count("Choice='Solid'")>=10
assert "'Convergence Criteria - Max Iterations'=1000" in text
assert "'Include Flow'=false" in text
assert hashlib.sha256(open(s['source_project'],'rb').read()).hexdigest()==s['source_project_sha256_before']
audit={'checked_at':datetime.datetime.now().isoformat(),'full_native_design_validation_passed':True,
       'native_setups':setups,'physical_part_count':len(parts['parts']),'geometry_and_material_assignments_preserved':True,
       'external_cooling_on_actual_solid_faces':True,'region_faces_excluded':True,'boundary_face_count':18,
       'cooling_area_m2':faces['total_area_m2'],'h_w_m2k':7,'ambient_C':25,
       'heat_W':5.5,'material_types_explicitly_solid':True,'requested_mesh_max_size_mm':[2,2,.05],
       'requested_mesh_min_gap_mm':[.05,.05,.01],'multilevel_meshing_enabled':False,
       'thin_layer_mesh_coverage_verified':False,'corrected_mesh_generated':False,
       'corrected_thermal_solve_completed':False,'temperatures_verified':False,
       'original_native_project_sha256_unchanged':True,
       'corrected_project_sha256':hashlib.sha256(open(pf,'rb').read()).hexdigest(),
       'pending':'User will run later. License checkout blocked the only corrected mesh attempt.'}
b.write_json(os.path.join(folder,'ready_configuration_audit.json'),audit)
shutil.copy2(os.path.join(os.path.dirname(s['source_project']),'input_snapshot.json'),os.path.join(folder,'original_inputs_unchanged.json'))
readme='''CORRECTED ICEPAK PHONE CASE READY TO RUN

Project: Illustrative_Phone_Corrected.aedt
Design: IcepakDesign1
Setup: Phone_Steady_Corrected

CHANGES SAVED AND CHECKED
- Original failed-run project is preserved and its SHA256 is unchanged.
- External_Convection now uses 18 actual exterior solid faces, excluding Region faces.
- Total assigned exterior area is 0.02776 m2, matching the phone envelope.
- Retained h = 7 W/(m2 K), ambient = 25 C and total heat = 5.5 W.
- Explicit Solid material choices are assigned to all ten custom solid materials.
- Requested maximum cell sizes X/Y/Z = 2 / 2 / 0.05 mm.
- Minimum gaps X/Y/Z = 0.05 / 0.05 / 0.01 mm; multilevel meshing disabled.
- Energy residual target = 1e-8; maximum iterations = 1000.
- Old failed result plot and setup removed from this corrected copy.
- Native full design validation passed with no validation messages.

STATUS
The corrected mesh attempt stopped at a solver-license host-not-found error.
No corrected mesh or thermal solution is available. Thin-layer coverage,
boundary coverage, heat balance and numerical convergence remain unverified.
The user chose to leave the corrected project ready and run it later.

RUN LATER THROUGH THE GUI
1. Keep/open Illustrative_Phone_Corrected.aedt in Electronics Desktop.
2. Expand Analysis. Right-click Phone_Steady_Corrected and select Generate Mesh.
   The company license connection must be reachable for this step.
3. Inspect Message Manager and Mesh Viewer before starting Analyze.
   Battery_TIM, PCB_TIM, Processor_TIM, Copper_Spreader and all other physical
   parts must have mesh. External_Convection must also have valid face mesh.
   If any missing-mesh warning remains, do not accept this mesh as corrected.
4. When mesh coverage is satisfactory, right-click Phone_Steady_Corrected > Analyze.
5. Open Residual, Thermal Monitor and Profile from that setup's right-click menu.
6. Check the actual energy residual reaches 1e-8, temperatures do not hit a
   solver limit and no temperature-limiting messages appear in the transcript.
7. Verify total outward heat transfer agrees with 5.5 W input (proposed numerical
   acceptance: less than 1 percent imbalance). Report maximum and mean battery
   temperatures separately, plus package maxima and maximum exterior temperature.
8. Perform a mesh refinement comparison before treating the thermal prediction
   as numerically established. The model's dimensions/materials/loads remain
   illustrative and do not constitute hardware validation.

TRANSIENT FOLLOW-UP
After a credible corrected steady case, create a separate transient study with
an explicit 25 C initial condition, justified heat-versus-time history and time
step sensitivity. Do not use the old capped 5000 K result as initial conditions.
'''
open(os.path.join(folder,'RUN_WHEN_READY.txt'),'w').write(readme)
s['stage']='ready_to_run_later_user_requested';s['license_blocker_confirmed']=True
s['ready_configuration_audit']='ready_configuration_audit.json';s['next_step']='Generate the corrected mesh when license connectivity is available; verify coverage before solving.'
s['source_project_sha256_after']=s['source_project_sha256_before']
b.write_json(os.path.join(folder,'repair_status.json'),s)
b.write_json(os.path.join(b.ROOT,'latest_repair.json'),{'folder':folder,'project':pf,'status':s['stage']})
print(json.dumps(audit,indent=2),flush=True)
