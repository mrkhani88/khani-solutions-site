from pathlib import Path
import json, shutil, hashlib, datetime, re, csv
ROOT=Path(__file__).parent
SRC=ROOT/'repair_20261018_193055'
OUT=ROOT/'corrected_report_20261018'
EV=OUT/'evidence'; IM=OUT/'images'
EV.mkdir(parents=True,exist_ok=True); IM.mkdir(exist_ok=True)
SNAP=EV/'saved_run_snapshot'; SNAP.mkdir(exist_ok=True)
for name in ['Illustrative_Phone_Corrected.aedt','original_inputs_unchanged.json','exterior_cooling_face_audit.json','ready_configuration_audit.json','repair_status.json','RUN_WHEN_READY.txt']:
    shutil.copy2(SRC/name,SNAP/name)
shutil.copytree(SRC/'Illustrative_Phone_Corrected.aedtresults',SNAP/'Illustrative_Phone_Corrected.aedtresults',dirs_exist_ok=True,ignore=shutil.ignore_patterns('*.semaphore'))
R=SNAP/'Illustrative_Phone_Corrected.aedtresults'/'IcepakDesign1.results'
def ser(path):
    return [[float(a),float(b)] for a,b in re.findall(r'([\d.eE+\-]+)\s+\w+\(([\d.eE+\-]+)\)',path.read_text())]
names=['Rear_Cover','Display_Glass','Display_Layer','Battery_Cell','Main_PCB','Processor_Package','PMIC_Package','Memory_Package','Camera_Module']
res=ser(R/'DV68_S108_MON0_V12.sd')
mon={n:ser(next(R.glob('DV68_S108_MON%d_*.sd'%i))) for i,n in enumerate(names,1)}
sov=(R/'DV68_S108_V132_137.SOV').read_text()
maxima={n:float(v)-273.15 for n,v in re.findall(r"Heat_(\w+)='([\d.eE+\-]+)kel'",sov)}
log=(R/'DV68_S108_V131.restart'/'current.uns_out').read_text(errors='replace')
errors=[{'line':i,'text':line} for i,line in enumerate(log.splitlines(),1) if re.search(r'error:|error object:|warning|temperature limited|diverg',line,re.I)]
with (EV/'component_maximum_temperatures_C.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['component','maximum_temperature_C','source']);w.writerows([[n,t,'native SOV volume maximum'] for n,t in maxima.items()])
with (EV/'vertex_average_temperature_monitors_C.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['iteration']+names);w.writerows([[res[i][0]]+[mon[n][i][1] for n in names] for i in range(len(res))])
with (EV/'energy_residual.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['iteration','energy_residual']);w.writerows(res)
cfg=json.loads((SRC/'original_inputs_unchanged.json').read_text())
with (EV/'part_inventory.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['part','x_mm','y_mm','z_mm','dx_mm','dy_mm','dz_mm','material','heat_W']);w.writerows([[p['name']]+p['xyz']+p['size']+[p['material'],p['power_w']] for p in cfg['parts']])
facts={'created':datetime.datetime.now().isoformat(),'source_project':str(SRC/'Illustrative_Phone_Corrected.aedt'),'configuration':cfg,'project':'Illustrative_Phone_Corrected','design':'IcepakDesign1','setup':'Phone_Steady_Corrected','software':'Ansys Electronics Desktop 2026 R1 / Icepak','cells':671368,'nodes':697776,'mesh_stop':'2026-10-18 20:19:11 PDT','solve_start':'2026-10-18 20:19:25 PDT','solve_stop':'2026-10-18 20:20:29 PDT','solve_elapsed_profile_seconds':63,'solver_cores':4,'mesh_completed':True,'solve_completed':True,'normal_completion':True,'outer_iterations':len(res),'energy_residual':res[-1][1],'energy_target':1e-8,'maxima_C':maxima,'monitor_end_C':{n:v[-1][1] for n,v in mon.items()},'monitor_statistic':'Vertex Average; not volume average','temperature_limiter_messages':len(re.findall('temperature limited',log,re.I)),'transcript_diagnostics':errors,'global_heat_balance_verified':False,'mesh_independence_verified':False,'physical_validation':False,'new_simulations_started_by_report_task':0,'historical_status_note':'The readiness/repair JSON files predate the user-performed completed run and are preserved as historical snapshots. Native profiles, transcript, SOV and monitors establish completion.'}
(EV/'report_facts.json').write_text(json.dumps(facts,indent=2))
manifest=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(SNAP.rglob('*')) if p.is_file()]
(EV/'snapshot_sha256_manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in facts.items() if k not in ['configuration']},indent=2))
