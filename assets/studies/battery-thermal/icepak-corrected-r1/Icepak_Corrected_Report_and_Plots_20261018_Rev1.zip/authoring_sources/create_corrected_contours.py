from pathlib import Path
import json, datetime, sys
import build_phone_icepak as b
ROOT=Path(__file__).parent; OUT=ROOT/'corrected_report_20261018'; IM=OUT/'images'; EV=OUT/'evidence'
app=b.desktop(); p=app.GetActiveProject(); d=p.GetActiveDesign()
assert p.GetName()=='Illustrative_Phone_Corrected'
e=d.SetActiveEditor('3D Modeler'); f=d.GetModule('FieldsReporter')
audit={'created':datetime.datetime.now().isoformat(),'errors':{},'exported':[]}
def call(name,fn):
    try: val=fn(); audit[name]=val; print(name,repr(val)[:600],flush=True); return val
    except Exception as ex: audit['errors'][name]=str(ex); print(name,'ERROR',str(ex),flush=True)
cfg=json.loads((ROOT/'phone_inputs.json').read_text())
views=[('Battery_Temperature',['Battery_Cell']),('Electronics_Temperature',['Main_PCB','Processor_Package','PMIC_Package','Memory_Package','Camera_Module','Copper_Spreader','Spreader_Display_Pad']),('Exterior_Temperature',['Rear_Cover','Frame_Left','Frame_Right','Frame_Bottom','Frame_Top','Display_Glass'])]
if '--mesh' in sys.argv:views=[('Surface_Mesh',['Battery_Cell','Main_PCB','Processor_Package','PMIC_Package','Memory_Package','Camera_Module','Copper_Spreader','Spreader_Display_Pad'])]
for name,objects in views:
    if name in list(f.GetFieldPlotNames()): f.DeleteFieldPlot([name])
    args=['NAME:'+name,'SolutionName:=','Phone_Steady_Corrected : SteadyState','UserSpecifyName:=',1,'UserSpecifyFolder:=',1,'QuantityName:=','Temperature','PlotFolder:=','Temperature','StreamlinePlot:=',False,'AdjacentSidePlot:=',False,'FullModelPlot:=',False,'IntrinsicVar:=','','PlotGeomInfo:=',[1,'Surface','FacesList',len(objects)]+objects,'FilterBoxes:=',[0],['NAME:PlotOnSurfaceSettings','ShadingType:=',0,'Filled:=',True,'IsoValType:=','Tone','AddGrid:=',False,'MapTransparency:=',False,'Refinement:=',0,'Transparency:=',0,'SmoothingLevel:=',0,['NAME:Arrow3DSpacingSettings','ArrowUniform:=',True,'ArrowSpacing:=',0,'MinArrowSpacing:=',0,'MaxArrowSpacing:=',0],'GridColor:=',[255,255,255]],'EnableGaussianSmoothing:=',False,'SurfaceOnly:=',True]
    if name=='Surface_Mesh':
        surf=args[args.index('FilterBoxes:=')+2]
        surf[surf.index('AddGrid:=')+1]=True
        surf[surf.index('GridColor:=')+1]=[35,35,35]
    call('create_'+name,lambda:f.CreateFieldPlot(args,'Field'))
    call('export_'+name,lambda:f.ExportPlotImageWithViewToFile(str(IM/(name+'_native.png')),'Temperature',name,1800,1200,'Trimetric'))
    if (IM/(name+'_native.png')).exists():audit['exported'].append(name)
    if name!='Surface_Mesh':call('remove_'+name,lambda:f.DeleteFieldPlot([name]))
call('messages',lambda:list(app.GetMessages(p.GetName(),d.GetName(),0)))
(EV/('native_mesh_export_audit.json' if '--mesh' in sys.argv else 'native_contour_export_audit.json')).write_text(json.dumps(audit,indent=2,default=str))
