from pathlib import Path
import json,datetime
import build_phone_icepak as b
ROOT=Path(__file__).parent; OUT=ROOT/'corrected_report_20261018'; EV=OUT/'evidence'
app=b.desktop(); p=app.GetActiveProject(); d=p.GetActiveDesign(); assert p.GetName()=='Illustrative_Phone_Corrected'
f=d.GetModule('FieldsReporter'); audit={'created':datetime.datetime.now().isoformat(),'errors':{}}
cfg=json.loads((ROOT/'phone_inputs.json').read_text())
args=['SolutionName:=','Phone_Steady_Corrected : SteadyState','Variation:=','Nominal']
for part in cfg['parts']:
    args+=['Calculation:=',['Object','Volume',part['name'],'Temperature','','Default','Reduced','Nominal',False]]
args+=['Calculation:=',['Boundary','Surface','External_Convection','HeatFlowRate','','Default','Reduced','Nominal',False]]
try:
    f.EditFieldsSummarySetting(args)
    f.ExportFieldsSummary(['SolutionName:=','Phone_Steady_Corrected : SteadyState','DesignVariationKey:=','Nominal','ExportFileName:=',str(EV/'native_component_fields_summary.csv'),'IntrinsicValue:=',''])
    audit['summary_exported']=(EV/'native_component_fields_summary.csv').exists()
except Exception as ex:audit['errors']['summary_export']=str(ex)
print(json.dumps(audit,indent=2));(EV/'fields_summary_audit.json').write_text(json.dumps(audit,indent=2))
