"""Create an illustrative phone in an ALREADY OPEN AEDT session.

Run with Automation > Run Script in a NEW EMPTY ICEPAK DESIGN opened by
the user with the VPN connected, or attach through the installed Ansys
gRPC API. Does not launch an application or request a new design.
--validate-only performs offline checks without connecting to AEDT.
Default action builds and saves; --solve also meshes and starts the solver.
Runtime/API compatibility remains unverified until executed in licensed AEDT.
"""
from __future__ import print_function
import datetime
import hashlib
import itertools
import json
import os
import sys
import traceback

ROOT = r'C:\Users\m.khani\Desktop\Wisk\outputs\icepak_phone_demo_20261018'
INPUT = os.path.join(ROOT, 'phone_inputs.json')
DESIGN = 'Phone_Conduction_Demo'
SETUP = 'Phone_Steady'


def write_json(path, value):
    with open(path, 'w') as output:
        json.dump(value, output, indent=2, sort_keys=True)


def validate(cfg):
    parts = cfg['parts']
    names = [p['name'] for p in parts]
    assert len(names) == len(set(names)), 'Part names must be unique'
    envelope = cfg['envelope_mm']
    contacts = []
    for part in parts:
        assert part['material'] in cfg['materials']
        assert part['power_w'] >= 0
        for axis in range(3):
            assert part['size'][axis] > 0
            assert part['xyz'][axis] >= -1e-8
            assert part['xyz'][axis] + part['size'][axis] <= envelope[axis] + 1e-8
    for a, b in itertools.combinations(parts, 2):
        overlaps = [min(a['xyz'][i] + a['size'][i], b['xyz'][i] + b['size'][i])
                    - max(a['xyz'][i], b['xyz'][i]) for i in range(3)]
        assert not all(x > 1e-8 for x in overlaps), 'Solid overlap: %s / %s' % (a['name'], b['name'])
        if min(overlaps) >= -1e-8 and sum(x > 1e-8 for x in overlaps) == 2:
            contacts.append([a['name'], b['name']])
    power = sum(p['power_w'] for p in parts)
    assert abs(power - 5.5) < 1e-8, 'Unexpected heat budget'
    # Every solid must have a face-contact path to the rear cover.
    reached = set(['Rear_Cover'])
    while True:
        new = set(reached)
        for a, b in contacts:
            if a in reached or b in reached:
                new.update([a, b])
        if new == reached:
            break
        reached = new
    assert len(reached) == len(parts), 'Disconnected thermal solids: %s' % (set(names) - reached)
    return {'part_count': len(parts), 'total_heat_w': power,
            'no_solid_volume_overlaps': True, 'all_parts_inside_phone': True,
            'solid_contact_graph_connected': True, 'face_contacts': contacts,
            'runtime_tested': False, 'solver_executed': False}


def desktop():
    # In AEDT's Run Script environment, use its existing desktop object.
    if 'oDesktop' in globals():
        return globals()['oDesktop']
    api = r'C:\Program Files\ANSYS Inc\v261\AnsysEM\PythonFiles\DesktopPlugin'
    sys.path.insert(0, api)
    import ScriptEnv
    ScriptEnv.Connect('localhost', 50051)
    import PyDesktopPlugin
    PyDesktopPlugin.set_print_except_and_stop_on_invoke_error(False)
    import __main__
    return __main__.oDesktop


def unit(value, suffix='mm'):
    return ('%.10g' % value) + suffix


def attributes(name, material, color, transparency=0):
    return ['NAME:Attributes', 'Name:=', name, 'Flags:=', '',
            'Color:=', '(%d %d %d)' % tuple(color),
            'Transparency:=', transparency, 'PartCoordinateSystem:=', 'Global',
            'MaterialValue:=', '"%s"' % material, 'SurfaceMaterialValue:=', '"Steel-oxidised-surface"',
            'SolveInside:=', True, 'IsMaterialEditable:=', True]


def run(cfg, solve=False):
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    folder = os.path.join(ROOT, 'run_' + stamp)
    os.makedirs(folder)  # Never overwrite an existing model or result package.
    write_json(os.path.join(folder, 'input_snapshot.json'), cfg)
    fingerprint = hashlib.sha256(json.dumps(cfg, sort_keys=True).encode('utf-8')).hexdigest()
    status = {'stage': 'connecting', 'input_sha256': fingerprint,
              'solver_executed': False, 'solution_verified': False,
              'runtime_tested': False, 'warnings': []}
    status_path = os.path.join(folder, 'run_status.json')

    def stage(value):
        status['stage'] = value
        write_json(status_path, status)
        print(value)

    try:
        stage('connecting_to_existing_desktop')
        app = desktop()
        status['aedt_version'] = app.GetVersion()
        project = app.GetActiveProject()
        if project is None:
            raise RuntimeError('Open a new empty Icepak project/design while VPN is connected')
        design = project.GetActiveDesign()
        if design is None or design.GetDesignType() != 'Icepak':
            raise RuntimeError('Activate a new empty Icepak design first')
        if len(list(project.GetTopDesignList())) != 1:
            raise RuntimeError('Use a new project containing only the empty demonstration Icepak design')
        editor = design.SetActiveEditor('3D Modeler')
        existing = list(editor.GetObjectsInGroup('Solids'))
        if any(name != 'Region' for name in existing):
            raise RuntimeError('The active Icepak design already contains solids; existing work will not be modified')
        status['design_name'] = design.GetName()
        stage('using_existing_empty_icepak_design')
        editor.SetModelUnits(['NAME:Units Parameter', 'Units:=', 'mm', 'Rescale:=', False])
        defs = project.GetDefinitionManager()
        stage('creating_materials_and_geometry')
        for name, material in cfg['materials'].items():
            data = ['NAME:' + name, 'CoordinateSystemType:=', 'Cartesian',
                    'BulkOrSurfaceType:=', 1, ['NAME:PhysicsTypes', 'set:=', ['Thermal']],
                    'thermal_material_type:=', 'Solid',
                    'mass_density:=', str(material['rho']), 'specific_heat:=', str(material['cp'])]
            conductivity = material['k']
            if isinstance(conductivity, list):
                data.append(['NAME:thermal_conductivity', 'property_type:=', 'AnisoProperty',
                             'unit:=', 'W_per_mK', 'component1:=', str(conductivity[0]),
                             'component2:=', str(conductivity[1]), 'component3:=', str(conductivity[2])])
            else:
                data.extend(['thermal_conductivity:=', str(conductivity)])
            defs.AddMaterial(data)
        for part in cfg['parts']:
            x, y, z = part['xyz']
            dx, dy, dz = part['size']
            editor.CreateBox(['NAME:BoxParameters', 'XPosition:=', unit(x),
                              'YPosition:=', unit(y), 'ZPosition:=', unit(z),
                              'XSize:=', unit(dx), 'YSize:=', unit(dy), 'ZSize:=', unit(dz)],
                             attributes(part['name'], part['material'], part['color'], part.get('transparency', 0)))
        project_path = os.path.join(folder, 'Illustrative_Phone.aedt')
        project.SaveAs(project_path, True)
        status['project_file'] = project_path
        stage('geometry_checkpoint_saved')
        # Icepak creates a default Region. Replace only that object in this NEW project.
        solids = list(editor.GetObjectsInGroup('Solids'))
        if 'Region' in solids:
            editor.Delete(['NAME:Selections', 'Selections:=', 'Region'])
        region = ['NAME:RegionParameters']
        for axis in ['+X', '-X', '+Y', '-Y', '+Z', '-Z']:
            region.extend([axis + 'PaddingType:=', 'Absolute Offset', axis + 'Padding:=', '0mm'])
        editor.CreateRegion(region, attributes('Region', 'air', [180, 205, 230], 1))
        design.SetDesignSettings(['NAME:Design Settings Data',
                                 'AmbientTemperature:=', unit(cfg['ambient_c'], 'cel'),
                                 'AmbientRadiationTemperature:=', unit(cfg['ambient_c'], 'cel'),
                                 'AmbientPressure:=', '0n_per_meter_sq'])
        boundary = design.GetModule('BoundarySetup')
        for part in cfg['parts']:
            if part['power_w'] > 0:
                boundary.AssignBlockBoundary(['NAME:Heat_' + part['name'], 'Objects:=', [part['name']],
                                              'Block Type:=', 'Solid', 'Use External Conditions:=', False,
                                              'Use Total Power:=', True, 'Total Power:=', unit(part['power_w'], 'W')])
        faces = [int(x) for x in editor.GetFaceIDs('Region')]
        if len(faces) != 6:
            raise RuntimeError('Expected six outer region faces')
        boundary.AssignStationaryWallBoundary(['NAME:External_Convection', 'Faces:=', faces,
            'Thickness:=', '0mm', 'Solid Material:=', 'Phone_Aluminium',
            'External Material:=', 'Steel-oxidised-surface', 'Internal Material:=', 'Steel-oxidised-surface',
            'External Condition:=', 'Heat Transfer Coefficient', 'Heat Flux:=', '0irrad_W_per_m2',
            'Temperature:=', unit(cfg['ambient_c'], 'cel'),
            'Heat Transfer Coefficient:=', unit(cfg['external_h_w_m2k'], 'w_per_m2kel'),
            'Reference Temperature:=', unit(cfg['ambient_c'], 'cel'),
            ['NAME:Heat Transfer Data', 'Heat Transfer Correlation:=', False,
             'Heat Transfer Convection Type:=', 'Natural Convection'],
            ['NAME:Radiation', 'Radiate:=', False], 'Shell Conduction:=', False])
        mesh = design.GetModule('MeshRegion')
        mesh.EditGlobalMeshRegion(['NAME:Settings', 'MeshMethod:=', 'MesherHD',
            'UserSpecifiedSettings:=', True, 'ComputeGap:=', True,
            'MaxElementSizeX:=', '2mm', 'MaxElementSizeY:=', '2mm', 'MaxElementSizeZ:=', '0.3mm',
            'MinElementsInGap:=', '2', 'MinElementsOnEdge:=', '2', 'MaxSizeRatio:=', '2',
            'NoOGrids:=', False, 'EnableMLM:=', True, 'EnforeMLMType:=', '3D',
            'MaxLevels:=', '0', 'BufferLayers:=', '0', 'UniformMeshParametersType:=', 'XYZMaxSizes',
            'StairStepMeshing:=', False, 'MinGapX:=', '0.1mm', 'MinGapY:=', '0.1mm',
            'MinGapZ:=', '0.1mm', 'Objects:=', ['Region']])
        setup = design.GetModule('AnalysisSetup')
        setup.InsertSetup('IcepakSteadyState', ['NAME:' + SETUP, 'Enabled:=', True,
            'Flow Regime:=', 'Laminar', 'Include Temperature:=', True, 'Include Flow:=', False,
            'Include Gravity:=', False, 'Solution Initialization - Temperature:=', unit(cfg['ambient_c'], 'cel'),
            'Convergence Criteria - Energy:=', '1e-8', 'Radiation Model:=', 'Off',
            'Discretization Scheme - Temperature:=', 'Second',
            'Convergence Criteria - Max Iterations:=', cfg['solve_iterations']])
        monitors = design.GetModule('Monitor')
        for part in cfg['parts']:
            if part['power_w'] > 0 or part['name'] in ['Rear_Cover', 'Display_Glass', 'Main_PCB']:
                monitors.AssignPointMonitor(['NAME:T_' + part['name'], 'Quantities:=', ['Temperature'],
                                            'DefaultNameOverridden:=', False, 'Objects:=', [part['name']]])
        editor.FitAll()
        project.Save()
        stage('configured_model_saved')
        valid = int(design.ValidateDesign())
        status['design_validation_passed'] = valid == 1
        if valid != 1:
            raise RuntimeError('AEDT validation failed; inspect Message Manager before meshing')
        status['runtime_tested'] = True
        if not solve:
            stage('built_and_validated_not_solved')
            return folder
        stage('generating_mesh')
        mesh_result = int(design.GenerateMesh([SETUP]))
        status['mesh_return_code'] = mesh_result
        if mesh_result != 0:
            raise RuntimeError('Icepak mesh generation failed')
        project.Save()
        stage('solving')
        status['solver_executed'] = True
        write_json(status_path, status)
        design.Analyze(SETUP)
        project.Save()
        stage('exporting_results_for_review')
        fields = design.GetModule('FieldsReporter')
        summary = ['SolutionName:=', SETUP + ': SteadyState', 'Variation:=', 'Nominal']
        for part in cfg['parts']:
            summary.extend(['Calculation:=', ['Object', 'Volume', part['name'], 'Temperature', '',
                                              'Default', 'Reduced', 'Nominal', False]])
        fields.EditFieldsSummarySetting(summary)
        fields.ExportFieldsSummary(['SolutionName:=', SETUP + ': SteadyState',
            'DesignVariationKey:=', 'Nominal', 'ExportFileName:=', os.path.join(folder, 'component_temperatures.csv'),
            'IntrinsicValue:=', ''])
        try:
            design.ExportConvergence(SETUP, '', os.path.join(folder, 'convergence.conv'))
        except Exception as error:
            status['warnings'].append('Convergence export needs GUI review: ' + str(error))
        # Exports alone do not establish convergence, conservation or mesh independence.
        stage('solve_returned_results_require_convergence_energy_and_mesh_review')
        return folder
    except Exception:
        status['stage'] = 'failed_or_blocked'
        status['error'] = traceback.format_exc()
        write_json(status_path, status)
        raise


def main():
    with open(INPUT) as source:
        cfg = json.load(source)
    checks = validate(cfg)
    write_json(os.path.join(ROOT, 'offline_checks.json'), checks)
    if '--validate-only' in sys.argv:
        print(json.dumps(checks, indent=2))
        return
    run(cfg, solve='--solve' in sys.argv)


if __name__ == '__main__':
    main()
