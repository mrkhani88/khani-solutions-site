from pathlib import Path
import json, datetime, traceback
import build_phone_icepak as b
ROOT=Path(__file__).parent; OUT=ROOT/'corrected_report_20261018'; IM=OUT/'images'; EV=OUT/'evidence'
app=b.desktop(); p=app.GetActiveProject(); d=p.GetActiveDesign()
assert p.GetName()=='Illustrative_Phone_Corrected' and d.GetName()=='IcepakDesign1'
e=d.SetActiveEditor('3D Modeler'); f=d.GetModule('FieldsReporter')
audit={'created':datetime.datetime.now().isoformat(),'project':p.GetName(),'design':d.GetName(),'project_path':p.GetPath(),'software_version':app.GetVersion(),'errors':{}}
def call(name,fn):
    try:
        val=fn(); audit[name]=val; print(name,repr(val)[:700],flush=True); return val
    except Exception as ex:
        audit['errors'][name]=str(ex); print(name,'ERROR',str(ex),flush=True)
call('messages',lambda:list(app.GetMessages(p.GetName(),d.GetName(),0)))
call('field_plots',lambda:list(f.GetFieldPlotNames()))
call('field_folders',lambda:list(f.GetFieldFolderNames()))
call('mesh_plots',lambda:list(f.GetMeshPlotNames()))
call('boundary_faces',lambda:list(d.GetModule('BoundarySetup').GetAssignment('External_Convection')))
call('fit_model',lambda:e.FitAll())
call('native_model_export',lambda:e.ExportModelImageToFile(str(IM/'corrected_native_model.png'),1800,1200,['NAME:SaveImageParams','ShowAxis:=','True','ShowGrid:=','False','ShowRuler:=','True','ShowRegion:=','False','Selections:=','','FieldPlotSelections:=','','Orientation:=','Trimetric']))
(EV/'live_native_audit.json').write_text(json.dumps(audit,indent=2,default=str))
