"""Repair the active illustrative phone in a new native project; preserve source."""
import datetime,hashlib,json,os,re,shutil,traceback
import build_phone_icepak as b

ROOT=b.ROOT
SOURCE=os.path.join(ROOT,'run_20261018_171547','Illustrative_Phone.aedt')
STAMP=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
FOLDER=os.path.join(ROOT,'repair_'+STAMP)
os.makedirs(FOLDER)
PROJECT=os.path.join(FOLDER,'Illustrative_Phone_Corrected.aedt')
SETUP='Phone_Steady_Corrected'
cfg=json.load(open(os.path.join(os.path.dirname(SOURCE),'input_snapshot.json')))
source_sha=hashlib.sha256(open(SOURCE,'rb').read()).hexdigest()
status={'stage':'connecting','source_project':SOURCE,'source_project_sha256_before':source_sha,
        'project_file':PROJECT,'setup':SETUP,'geometry_changed':False,
        'mesh_generated':False,'solver_executed':False,'solution_verified':False,
        'mesh_coverage_verified':False,'warnings':[],'created':datetime.datetime.now().isoformat()}
def save():b.write_json(os.path.join(FOLDER,'repair_status.json'),status)
def stage(s):status['stage']=s;save();print(s,flush=True)
def mat_data(name,m):
    a=['NAME:'+name,'CoordinateSystemType:=','Cartesian','BulkOrSurfaceType:=',1,
       ['NAME:PhysicsTypes','set:=',['Thermal']],
       ['NAME:thermal_material_type','property_type:=','ChoiceProperty','Choice:=','Solid'],
       'mass_density:=',str(m['rho']),'specific_heat:=',str(m['cp'])]
    k=m['k']
    if isinstance(k,list):a.append(['NAME:thermal_conductivity','property_type:=','AnisoProperty','unit:=','W_per_mK','component1:=',str(k[0]),'component2:=',str(k[1]),'component3:=',str(k[2])])
    else:a.extend(['thermal_conductivity:=',str(k)])
    return a
try:
    app=b.desktop();p=app.GetActiveProject();d=p.GetActiveDesign()
    assert p.GetName()=='Illustrative_Phone' and d.GetName()=='IcepakDesign1'
    assert os.path.normcase(os.path.normpath(p.GetPath()))==os.path.normcase(os.path.dirname(SOURCE))
    stage('saving_separate_corrected_project')
    p.SaveAs(PROJECT,False)
    assert p.GetName()=='Illustrative_Phone_Corrected'
    d=p.GetActiveDesign();e=d.SetActiveEditor('3D Modeler')
    # Remove failed-run visual overlays and setup from this derivative only.
    fields=d.GetModule('FieldsReporter');oldplots=list(fields.GetFieldPlotNames())
    if oldplots:fields.DeleteFieldPlot(oldplots)
    analysis=d.GetModule('AnalysisSetup')
    oldsetups=list(analysis.GetSetups())
    if oldsetups:analysis.DeleteSetups(oldsetups)
    stage('correcting_explicit_solid_material_types')
    defs=p.GetDefinitionManager()
    for name,mat in cfg['materials'].items():defs.EditMaterial(name,mat_data(name,mat))
    stage('selecting_physical_exterior_faces')
    ext=[]
    envelope=cfg['envelope_mm']
    for part in cfg['parts']:
        for fid in e.GetFaceIDs(part['name']):
            center=[float(x) for x in e.GetFaceCenter(int(fid))]
            planes=[]
            for axis in range(3):
                if abs(center[axis])<1e-7:planes.append(['XYZ'[axis],0])
                if abs(center[axis]-envelope[axis])<1e-7:planes.append(['XYZ'[axis],envelope[axis]])
            if planes:ext.append({'object':part['name'],'face_id':int(fid),'center_mm':center,'area_mm2':float(e.GetFaceArea(int(fid))),'outer_planes':planes})
    area=sum(x['area_mm2'] for x in ext)
    expected=2*(75*160+75*8+160*8)
    assert len(ext)==18 and len(set(x['face_id'] for x in ext))==18
    assert abs(area-expected)<1e-5,(area,expected)
    regionfaces=set(int(x) for x in e.GetFaceIDs('Region'))
    assert not regionfaces.intersection(x['face_id'] for x in ext)
    boundary=d.GetModule('BoundarySetup')
    boundary.EditStationaryWallBoundary('External_Convection',[
        'NAME:External_Convection','Faces:=',[x['face_id'] for x in ext],
        'Thickness:=','0mm','Solid Material:=','Phone_Aluminium',
        'External Material:=','Steel-oxidised-surface','Internal Material:=','Steel-oxidised-surface',
        'External Condition:=','Heat Transfer Coefficient','Heat Flux:=','0irrad_W_per_m2',
        'Temperature:=','25cel','Heat Transfer Coefficient:=','7w_per_m2kel','Reference Temperature:=','25cel',
        ['NAME:Heat Transfer Data','Heat Transfer Correlation:=',False,'Heat Transfer Convection Type:=','Natural Convection'],
        ['NAME:Radiation','Radiate:=',False],'Shell Conduction:=',False])
    # Boundary editing changes properties; reassignment is a separate native operation.
    boundary.Reassign(['NAME:External_Convection','Faces:=',[x['face_id'] for x in ext]])
    assert sorted(int(x) for x in boundary.GetAssignment('External_Convection'))==sorted(x['face_id'] for x in ext)
    b.write_json(os.path.join(FOLDER,'exterior_cooling_face_audit.json'),{'faces':ext,'total_area_mm2':area,'total_area_m2':area*1e-6,'expected_envelope_area_mm2':expected,'region_faces_excluded':sorted(regionfaces),'area_check_passed':True})
    stage('setting_mesh_to_resolve_thin_layers')
    mesh=d.GetModule('MeshRegion')
    mesh.EditGlobalMeshRegion(['NAME:Settings','MeshMethod:=','MesherHD','UserSpecifiedSettings:=',True,
        'ComputeGap:=',True,'MaxElementSizeX:=','2mm','MaxElementSizeY:=','2mm','MaxElementSizeZ:=','0.05mm',
        'MinElementsInGap:=','3','MinElementsOnEdge:=','2','MaxSizeRatio:=','2',
        'NoOGrids:=',False,'EnableMLM:=',False,'EnforeMLMType:=','3D','MaxLevels:=','0','BufferLayers:=','0',
        'UniformMeshParametersType:=','XYZMaxSizes','StairStepMeshing:=',False,
        'MinGapX:=','0.05mm','MinGapY:=','0.05mm','MinGapZ:=','0.01mm','Objects:=',['Region']])
    analysis.InsertSetup('IcepakSteadyState',['NAME:'+SETUP,'Enabled:=',True,
        'Flow Regime:=','Laminar','Include Temperature:=',True,'Include Flow:=',False,'Include Gravity:=',False,
        'Solution Initialization - Temperature:=','25cel','Convergence Criteria - Energy:=','1e-8',
        'Radiation Model:=','Off','Discretization Scheme - Temperature:=','Second',
        'Convergence Criteria - Max Iterations:=',1000])
    d.SetDesignSettings(['NAME:Design Settings Data','Perform Minimal validation:=',False,'AmbientTemperature:=','25cel','AmbientRadiationTemperature:=','25cel'])
    p.Save()
    text=open(PROJECT,encoding='utf-8',errors='replace').read()
    powers=[float(x) for x in re.findall(r"'Total Power'='([0-9.eE+-]+)W'",text)]
    assert len(powers)==6 and abs(sum(powers)-5.5)<1e-9
    assert "MaxElementSizeZ='0.05mm'" in text
    assert "MinGapZ='0.01mm'" in text and 'EnableMLM=false' in text
    assert text.count("Choice='Solid'")>=10
    assert "'Convergence Criteria - Energy'='1e-08'" in text or "'Convergence Criteria - Energy'='1e-8'" in text
    status.update({'cooling_area_m2':area*1e-6,'exterior_face_count':len(ext),'prescribed_heat_w':sum(powers),
        'mesh_requested_max_size_mm':[2,2,.05],'mesh_requested_min_gap_mm':[.05,.05,.01],
        'multilevel_meshing':False,'energy_residual_target':1e-8,'iteration_limit':1000,
        'new_setup_has_no_failed_results':True})
    stage('validating_corrected_native_design')
    valid=int(d.ValidateDesign());status['design_validation_passed']=valid==1
    msgs=list(app.GetMessages(p.GetName(),d.GetName(),0))
    b.write_json(os.path.join(FOLDER,'messages_after_validation.json'),msgs)
    assert valid==1,('Native validation failed',msgs)
    # Native geometry image only; no solved temperatures are implied.
    e.FitAll()
    e.ExportModelImageToFile(os.path.join(FOLDER,'corrected_native_model.png'),1800,1200,
        ['NAME:SaveImageParams','ShowAxis:=','True','ShowGrid:=','False','ShowRuler:=','True','ShowRegion:=','False','Selections:=','','FieldPlotSelections:=','','Orientation:=','Trimetric'])
    stage('attempting_corrected_mesh')
    try:
        rc=int(d.GenerateMesh([SETUP]));status['mesh_return_code']=rc
        msgs=list(app.GetMessages(p.GetName(),d.GetName(),0))
        b.write_json(os.path.join(FOLDER,'messages_after_mesh_attempt.json'),msgs)
        if rc!=0:raise RuntimeError('GenerateMesh returned '+str(rc))
        bad=[x for x in msgs if 'does not have mesh' in x.lower()]
        if bad:raise RuntimeError('Missing mesh remains: '+str(bad))
        status['mesh_generated']=True
        stage('mesh_generated_requires_cell_and_boundary_coverage_audit_before_solve')
    except Exception as error:
        status['mesh_attempt_error']=str(error)
        status['warnings'].append('Requested mesh resolution is not proof of generated mesh coverage.')
        stage('corrected_configuration_saved_mesh_generation_blocked_or_unverified')
    p.Save()
except Exception:
    status['error']=traceback.format_exc();stage('repair_incomplete_requires_review')
finally:
    status['source_project_sha256_after']=hashlib.sha256(open(SOURCE,'rb').read()).hexdigest()
    status['original_native_project_unchanged']=status['source_project_sha256_after']==source_sha
    save();b.write_json(os.path.join(ROOT,'latest_repair.json'),{'folder':FOLDER,'project':PROJECT,'status':status['stage']})
    print(json.dumps(status,indent=2),flush=True)
